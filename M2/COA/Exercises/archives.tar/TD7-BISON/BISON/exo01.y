%{
#include <stdio.h>
#include <stdlib.h>
#if YYBISON
int yylex();
int yyerror();
#endif
%}

%token NOMBRE


%%
instruction:
		expression { printf("= %d\n",$1); }
	;
expression:
		expression '-' expression { $$ = $1 - $3; }
	| 	NOMBRE { $$ = $1; }
	;  
%%

