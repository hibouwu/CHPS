#include <stdio.h>
#include <stdlib.h>

/*
Table des Symboles
	V[0] :  CONST 8
	V[1] :  CONST 4
	V[2] :  VAR  TEMP
	V[3] :  VAR  "a"
	V[4] :  CONST 3
	V[5] :  VAR  TEMP
	V[6] :  CONST 14
	V[7] :  VAR  TEMP
	V[8] :  VAR  "b"
*/

int main () {
	int V[9];
	V[3] =  2 ;
	printf("a = %d\n", V[3]);
	V[3] =  5 ;
	printf("a = %d\n", V[3]);
	V[8] =  7 ;
	printf("b = %d\n", V[8]);
	return 0;
}
