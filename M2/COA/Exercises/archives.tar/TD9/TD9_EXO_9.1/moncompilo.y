%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#if YYBISON
int yylex();
int yyerror();
#endif

%}


%union {
	char *nom;
	int val;
	}

%token <val> NOMBRE
%token <nom> NOMVAR

%token PLUS
%token MOINS
%token MULT
%token DIV
%token AFFECT

%token PRINT

%token PO
%token PF

%token FDL

%left PLUS MOINS
%left MULT DIV
%left AFFECT


%%
programme: 
		instruction { printf(" R  1\n"); }
	;
instruction:
		instructiondebase instruction { printf(" R  2\n"); }
	|	instructiondebase             { printf(" R  3\n"); }
	;
instructiondebase:
		affectation FDL { printf(" R  4\n"); }
	|	affichage FDL   { printf(" R  5\n"); }
	| 	FDL             { printf(" R  6\n"); }
	;
affichage:
		PRINT NOMVAR { printf(" R  7\n"); }
	;
affectation: variable_a_gauche AFFECT expression { printf(" R  8\n"); }
	;
expression:
		expression PLUS  expression { printf(" R  9\n"); }
	|	expression MOINS expression { printf(" R 10\n"); }
	|	expression MULT  expression { printf(" R 11\n"); }
	|	expression DIV   expression { printf(" R 12\n"); }
	|	PO expression PF            { printf(" R 13\n"); }
	| 	NOMBRE                      { printf(" R 14\n"); }
	| 	variable_a_droite           { printf(" R 15\n"); }
	; 
variable_a_gauche: NOMVAR { printf(" R 16\n");}
variable_a_droite: NOMVAR { printf(" R 17\n");}
	;
%%
