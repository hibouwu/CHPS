%{
#include <stdio.h>
#include <stdlib.h>
#if YYBISON
int yylex();
int yyerror();
#endif
%}

%token CONSTANTE
%token IMPLICATION
%token EQUIVALENCE
%token OU
%token ET
%token UNAIRE
%left 

%%
instruction:
		expression { printf("= %d\n",$1); }
	;
expression:
		expression ET expression { $$ = $1 && $3; }
	| 	CONSTANTE { $$ = $1; }
	;  
expression:
		expression OU expression { $$ = $1 || $3; }
	; 
expression:
		expression IMPLICATION expression { $$ = (!$1) ||($1 && $3);}
	; 
expression:
		expression EQUIVALENCE expression { $$ = ($1==$3)?1:0; }
	; 
expression:
		UNAIRE expression{$$ = ($1 == 0)?1:0;}
	; 
%%
