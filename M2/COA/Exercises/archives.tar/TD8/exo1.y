%{
#include <stdio.h>
#include <stdlib.h>
#if YYBISON
int yylex();
int yyerror();
#endif
%}

%token ID
%left '+' '-'
%left '*' 

%%
instruction :
		expression { printf("= %d\n",$1); }
	;   

expression :
        expression '+' expression {$$ = $1 + $3;}
    |   expression '-' expression {$$ = $1 - $3;}
    |   expression '*' expression {$$ = $1 * $3;}
    |   '('expression')' {$$ = $2;}
    |   ID {$$ = $1;}
    ;
%%