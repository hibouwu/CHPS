# 线性模型与稀疏性

> 从最小二乘出发，理解模型为什么会过拟合、正则化怎样改变解，以及线性方法如何扩展到非线性预测。正文沿用原课件顺序，概念解释与短例子就地展开，较长推导可折叠阅读。

[原 PDF](02_LM.pdf) · [原文转换稿](02_LM.md) · [逐块对应清单](Translation-audit/2026-09-28-coverage.json) · [课程目录](../README.md)

<a id="reading-example-navigation"></a>

例子导航：[三个点的最小二乘](#reading-ls-example) · [解的唯一性与敏感性](#reading-rank-and-stability) · [三种正则化的数值比较](#reading-elastic-net-example) · [交叉验证](#reading-cross-validation) · [三种惩罚的图像](#reading-penalty-exercise) · [核岭回归手算](#reading-kernel-ridge-example)

<details>
<summary>本讲目录（点击展开）</summary>

- [线性模型与稀疏性](#section-01)
- [监督机器学习：机器学习中的偏差—方差分解](#section-02)
- [统计学线性模型回顾：回归情形](#section-03)
- [线性回归中的最小二乘估计](#section-04)
- [线性模型中最小二乘计算的证明](#section-05)
- [基于链式法则的另一种证明](#section-06)
- [所有学生都（应该）知道的内容：回归中的偏差—方差权衡](#section-07)
- [机器学习如何接续线性回归](#section-08)
- [从经典统计到机器学习](#section-09)
- [高维插曲：一个令人意外的事实](#section-10)
- [从经典统计到机器学习：处理高维问题](#section-11)
- [对线性回归而言，“高维”意味着什么](#section-12)
- [A. 稀疏性与线性模型：调整模型维度](#section-13)
- [稀疏线性回归模型](#section-14)
- [两种表述：约束优化与惩罚优化](#section-15)
- [稀疏性与线性模型：模型选择](#section-16)
- [线性模型中的模型选择](#section-17)
- [线性模型中的模型选择](#section-18)
- [选读材料：赤池信息准则的推导](#section-19)
- [高维情况下的 AIC](#section-20)
- [A. 稀疏性与线性模型：从数理统计到优化](#section-21)
- [线性模型的 LASSO：从 $\ell _ { 0 }$ 到 $\ell _ { 1 }$](#section-22)
- [机器学习算法之“母”：惩罚优化](#section-23)
- [A. 稀疏性与线性模型：结构化稀疏性](#section-24)
- [A. 稀疏性与线性模型：岭回归](#section-25)
- [统计中的不适定问题：高维最小二乘回归](#section-26)
- [统计中最早的正则化方法：岭回归](#section-27)
- [岭回归估计量的推导](#section-28)
- [对偶优化问题：表述与 KKT 条件](#section-29)
- [对偶优化问题：求解](#section-30)
- [对偶优化问题：结果的解释](#section-31)
- [Elastic Net：兼得 LASSO 与 Ridge 的优点？](#section-32)
- [LASSO 与 Elastic Net：正则化路径比较](#section-33)
- [超参数调整：交叉验证](#section-34)
- [练习：比较三种惩罚](#section-35)
- [B. 估计非线性函数](#section-36)
- [核的魔力：核岭回归](#section-37)
- [基本核的例子](#section-38)
- [核机器学习估计：可行吗？](#section-39)
- [C. 推广：应用于其他估计问题](#section-40)

</details>

**数据科学与机器学习导论**

Nicolas Vayatis

<a id="section-01"></a>

## 线性模型与稀疏性

<a id="reading-model-and-learning"></a>

### 从一族函数中学出一个预测器

给定一组带标签的数据，学习算法要选出一个能预测新样本的函数。这里“模型”有两个常见含义：建模时，它指允许选择的函数族，例如所有 $h(t)=a+bt$；训练完成后，它也常指已经选定参数的那个函数，例如 $\widehat h(t)=2+1.5t$。前者规定可以怎样表达规律，后者是这次数据给出的具体结果。

本讲沿着三个问题展开：怎样在选定的函数族中拟合数据；变量很多时，怎样限制解的复杂度；怎样保留线性模型的求解方法，同时表达非线性关系。损失函数衡量预测与目标的差异，惩罚项表达希望解具有的性质，训练则把这两方面合在一起求最优参数。

<details>
<summary>延伸：标签逐渐到来时，数据怎样参与学习</summary>

一批历史数据可能只有输入，后来收集的数据则逐渐有了标签。例如，申请时能记录客户资料，实际还款结果要过一段时间才出现；图像也可以先收集，再陆续获得人工标注。已有标签帮助确定预测方向，无标签数据提供输入分布的信息，两者结合便形成半监督学习的情形。

无标签点能帮助看出数据集中在哪些区域、哪些区域几乎没有样本；能否据此改进分类，还取决于这些分布结构与标签之间的关系。系统运行一段时间后，可以用新增反馈更新预测器。若用户兴趣或环境发生变化，旧数据和新数据的参考价值也可能不同，此时还需要考虑时间窗口或对旧数据降低权重。

相似性方法会寻找与新样本接近的历史样本；本讲主要讨论的线性方法，则通过一个整体目标函数拟合参数。它们都需要说明什么叫“接近”或“预测得好”。把人群只用少数类别描述，与利用较丰富的个人历史进行预测，也对应不同的表示选择。

</details>

<details>
<summary>延伸：统计模型与预测模型的关系</summary>

统计模型常写成一族概率分布，例如均值和方差未知的高斯分布族；估计参数以后，就得到关于数据分布的描述。预测任务也可以直接选择决策函数，而不先估计完整的联合分布。例如，平方损失回归需要条件均值，二分类决策可以围绕类别概率的比较展开。

完整分布往往需要更多信息：一个不加结构限制的 $d$ 维高斯分布，仅均值和对称协方差就包含 $d+d(d+1)/2$ 个自由参数。直接预测允许围绕任务选择较具体的假设；它并不保证所有预测模型都比概率模型参数更少。

没有人工标签也可以定义优化目标。例如，给定密度族 $p_\theta$，可以最小化 $-\sum_i\log p_\theta(X_i)$。因此，“是否有标签”和“是否通过优化学习”是两个不同的问题。

</details>

<a id="section-02"></a>

## 监督机器学习：机器学习中的偏差—方差分解

### 一般设定与记号

- 学习目标：最优决策函数 $h^*:\mathcal X\to\mathcal Y$。$\mathcal X$ 是输入定义域，$\mathcal Y$ 是标签集合。
- 学习的输入：
- 训练数据：一组带标签的数据

$$
D _ {n} = \{(X _ {1}, Y _ {1}), \dots , (X _ {n}, Y _ {n}) \}
$$

其大小为 n，其中各观测对 $(X,Y)$ 属于 $\mathcal X\times\mathcal Y$。

- 假设空间：候选决策函数 $h:\mathcal X\to\mathcal Y$ 的集合 $\mathcal H$。
- 学习的输出：利用训练数据 $D _ { n }$ 估计得到、位于假设空间 $\mathcal { H }$ 中的经验决策函数 $\widehat { h }$。
- $\mathcal { H } \mathrm { : }$ 中的参照：该类中的最佳决策函数 $\bar { h }$（数据越多，$\widehat { h }$ 越接近 $\bar { h } )$）。

### 机器学习中的关键权衡

<a id="reading-three-functions"></a>

$h^*$ 是按选定损失衡量的总体最优函数，$\bar h$ 是限制在 $\mathcal H$ 后能达到的最佳函数，$\widehat h$ 是用这一次训练数据得到的函数。这里的 $L(h)$ 对未来样本的损失取平均；即使能算出训练误差，也通常不知道真实的 $L(h)$，因为未来数据的分布未知。

所有直线 $a+bt$ 构成一个无限集合，却仍然只能画出直线。如果目标关系是一条抛物线，再多数据也不能让这个函数族本身变成抛物线。这对应近似误差；有限样本使拟合结果偏离类内最佳直线，则对应估计误差。下面的等式把这两种差距分开。“最优”以损失和候选范围为准；目标中存在不可预测的噪声时，最优函数也有非零误差。此处假定相应最优函数存在。

- 对任意决策函数 h，用 $L ( h )$ 表示其误差度量。
- 有 $L ( \bar { h } ) = \operatorname* { i n f } _ { \mathcal { H } } L$，以及 $L ( h ^ { * } ) = \mathsf { i n f } L$。
- 对任意输出 $\widehat { h }$，误差具有如下偏差—方差类型的分解：

$$
L (\widehat {h}) - L (h ^ {*}) = \underbrace {L (\widehat {h}) - L (\bar {h})} _ {\text{估计误差（随机）}} + \underbrace {L (\bar {h}) - L (h ^ {*})} _ {\text{近似误差（确定性）}}
$$

假设类 H

![image](<Images/02_LM/image_001.jpg>)

### 关于近似误差

Cybenko（1989）：一个具有 Stone–Weierstrass 风格的稠密性结果，表明 sigmoid 与线性函数复合后所得函数的线性组合，在 d 维单位立方体上的连续函数空间中，关于上确界范数稠密。

- Barron（1994）：近似误差界包含一个刻画目标函数光滑程度的参数。
- 回归设定下这一问题的研究状况：
  - 对核方法：Smale（2003）、Steinwart（2008）的工作提供了完整理论。
  - 对深度学习：Grohs、Perekrestenko、Elbrächter 和 Bölcskei（2019）的近期工作。
- 在分类设定下，这是一个困难的问题，仍有待解决……

<a id="section-03"></a>

## 统计学线性模型回顾：回归情形

- 学习目标：$h^*:\mathbb R^d\to\mathbb R$。
- 观测：独立同分布的随机变量对 $( X _ { i } , Y _ { i } ) \in \mathbb { R } ^ { d } \times \mathbb { R }$。

$$
Y _ {i} = h ^ {*} (X _ {i}) + \varepsilon_ {i}, \quad i = 1, \dots , n
$$

其中 $\varepsilon _ { i }$ 是与 $X$ 独立的随机噪声变量。

- 下面使用如下向量记法：

$$
\mathbf {Y} = \mathbf {h} ^ {*} + \varepsilon
$$

其中三项都属于 $\mathbb { R } ^ { n }$。

- $\mathbb { R } ^ { n }$ 中的元素：

$$
\mathbf {Y} = \left(Y _ {1}, \dots , Y _ {n}\right) ^ {T},
$$

$$
\varepsilon = \left(\varepsilon_ {1}, \dots , \varepsilon_ {n}\right) ^ {T}
$$

- 像向量：对任意 $h \in \mathcal H$，用粗体表示

$$
\mathbf {h} = \left(h (X _ {1}), \dots , h (X _ {n})\right) ^ {T}
$$

- 数据点经 $\mathcal { H }$ 中的函数映射后得到的像集合为

$$
\mathcal {H} (X) = \left\{\mathbf {h} = \left(h \left(X _ {1}\right), \dots , h \left(X _ {n}\right)\right) ^ {T},: h \in \mathcal {H} \right\}
$$

- $\mathbb { R } ^ { n }$ 中的范数：

$$
\forall u = \left(u _ {1}, \ldots , u _ {n}\right) ^ {T} \in \mathbb {R} ^ {n}, \| u \| ^ {2} = \sum_ {i = 1} ^ {n} u _ {i} ^ {2}
$$

- 最小二乘估计（LSE）的定义：

$$
\widehat {\mathbf {h}} _ {\mathbf {n}} = \underset {\mathbf {h} \in \mathcal {H} (X)} {\arg \min} \frac {1}{n} \| \mathbf {Y} - \mathbf {h} \| ^ {2}
$$

其中 ${ \mathcal { H } } ( X ) = \{ \boldsymbol { \mathsf { h } } = ( h ( X _ { 1 } ) , \ldots , h ( X _ { n } ) ) ^ { T } , : h \in { \mathcal { H } } \}$。

- 假设线性模型为高斯模型，即噪声变量独立同分布、服从均值为零且方差固定并已知的高斯分布，则最小二乘估计也对应最大似然估计。
- 假设空间 $\mathcal { H }$ 是秩为 $d$ 的线性函数类。
- 噪声向量 $\boldsymbol { \varepsilon } = ( \varepsilon _ { 1 } , \ldots , \varepsilon _ { n } ) ^ { T }$ 是 $\mathbb { R } ^ { n }$ 中服从分布 ${ \mathcal { N } } _ { n } ( 0 , \sigma ^ { 2 } I _ { n } )$ 的高斯随机向量。

记号：$\boldsymbol { x } = ( \boldsymbol { x } ^ { ( 1 ) } , \ldots , \boldsymbol { x } ^ { ( d ) } ) ^ { T } \in \mathbb { R } ^ { d }$。

- 线性回归：$\begin{array} { r } { h ( x ) = \sum _ { k = 1 } ^ { d } \beta _ { k } x ^ { ( k ) } } \end{array}$。
- 基／框架展开（Fourier、样条、小波等）。
- 加性模型：$h ( x ) = \sum _ { k = 1 } ^ { d } f _ { k } ( x ^ { ( k ) } )$。
- 分段常数回归（考虑分段点）。

<a id="least-squares"></a>

<a id="reading-linear-in-parameters"></a>

### “线性”指对待估计参数线性

多项式 $h(t)=\beta_0+\beta_1t+\beta_2t^2$ 对输入 $t$ 不是线性的，但待估计系数 $\beta_0,\beta_1,\beta_2$ 都只以一次线性组合出现。把输入表示为 $(1,t,t^2)$ 后，仍然可以使用线性回归的方法。Fourier、样条和小波展开也有同样的形式：

$$
h(x)=\sum_{j=1}^{d}\beta_j\phi_j(x),
$$

其中基函数 $\phi_j$ 预先选定，训练负责估计系数。若连基函数内部的参数也要一起学习，就要重新判断模型是否仍对全部待估计参数线性。

还要区分一个函数和它在训练点上的取值。$h$ 接受任意新输入，而粗体 $\mathbf h=(h(X_1),\ldots,h(X_n))^T$ 只记录这 $n$ 个位置上的预测。$\mathcal H(X)$ 就是改变模型参数后，所有这些预测向量组成的集合。最小二乘在这个集合里寻找离观测向量 $\mathbf Y$ 最近的点。

在高斯噪声假设下，负对数似然等于一个与参数无关的常数，加上 $\|\mathbf Y-\mathbf X\beta\|^2/(2\sigma^2)$，所以最小二乘与最大似然给出同一组回归系数。最小二乘这个优化问题本身则可以在不假设高斯噪声时定义和求解。

<a id="section-04"></a>

## 线性回归中的最小二乘估计

- 用 $\pmb { \mathsf { X } } \in \mathbb { R } ^ { n \times d }$ 表示数据矩阵，$\boldsymbol { \beta } \in \mathbb { R } ^ { d }$ 表示待估计参数。
- 假设：X 满秩，其秩等于 d，并假设 $d \leq n$。
- 最小二乘估计的定义：$\begin{array} { r } { \widehat { \beta } _ { \mathfrak { n } } = \arg \min _ { \beta \in \mathbb { R } ^ { d } } \frac { 1 } { n } \| \pmb { \mathsf { Y } } - \pmb { \mathsf { X } } \beta \| ^ { 2 } } \end{array}$。
- 最小二乘估计：$\widehat { \mathbf { h } } _ { \mathbf { n } } = \mathbf { X } \widehat { \beta } _ { \mathbf { n } } = \mathbf { X } ( \mathbf { X } ^ { T } \mathbf { X } ) ^ { - 1 } \mathbf { X } ^ { T } \mathbf { Y } = \widehat { \Pi } \mathbf { Y }$。

![image](<Images/02_LM/image_002.jpg>)

<a id="reading-ls-example"></a>

### 用三个数据点看清矩阵与投影

沿用第一讲的数据：输入 $t=(-1,0,1)$，观测 $Y=(1,1,4)$，拟合直线 $h(t)=\beta_0+\beta_1t$。把常数项作为第一列特征，得到

$$
\mathbf X=
\begin{pmatrix}
1&-1\\
1&0\\
1&1
\end{pmatrix},\qquad
\mathbf Y=\begin{pmatrix}1\\1\\4\end{pmatrix},\qquad
\beta=\begin{pmatrix}\beta_0\\\beta_1\end{pmatrix}.
$$

每一行是一条观测，每一列是一种特征。这里 $n=3$、$d=2$；$\mathbf X\beta$ 是三个预测值组成的向量。计算得到

$$
\mathbf X^T\mathbf X=\begin{pmatrix}3&0\\0&2\end{pmatrix},
\qquad
\mathbf X^T\mathbf Y=\begin{pmatrix}6\\3\end{pmatrix},
\qquad
\widehat\beta=\begin{pmatrix}2\\1.5\end{pmatrix}.
$$

于是 $\widehat{\mathbf h}=(0.5,2,3.5)^T$，残差 $\mathbf r=\mathbf Y-\widehat{\mathbf h}=(0.5,-1,0.5)^T$，残差平方和为 $1.5$，平均平方误差为 $0.5$。

改变两个系数，$\mathbf X\beta$ 只能在两列向量 $(1,1,1)^T$ 和 $(-1,0,1)^T$ 张成的平面内移动。最优预测就是 $\mathbf Y$ 到这个平面的正交投影。直接验算：

$$
(1,1,1)\mathbf r=0.5-1+0.5=0,\qquad
(-1,0,1)\mathbf r=-0.5+0.5=0.
$$

残差与两列都垂直，说明沿任何允许的模型方向调整预测，都不能再缩短到 $\mathbf Y$ 的距离。这正是正规方程 $\mathbf X^T(\mathbf Y-\mathbf X\widehat\beta)=0$ 的几何含义。这里的平面位于“每个坐标对应一条观测”的 $\mathbb R^3$，与原来画散点的 $(t,Y)$ 平面是两种表示。[最小二乘的几何解释](https://www.seas.ucla.edu/~vandenbe/133A/lectures/ls.pdf)

<details>
<summary>推导：正交条件为什么保证得到最小值</summary>

任何另一组系数可以写成 $\widehat\beta+\Delta$。相应残差为 $\mathbf r-\mathbf X\Delta$。由于 $\mathbf r$ 与 $\mathbf X$ 的列空间正交，

$$
\|\mathbf Y-\mathbf X(\widehat\beta+\Delta)\|^2
=\|\mathbf r\|^2+\|\mathbf X\Delta\|^2
\geq\|\mathbf r\|^2.
$$

若 $\mathbf X$ 列满秩，只有 $\Delta=0$ 才能取等号，因此系数解唯一。正交投影矩阵还满足 $\widehat\Pi^T=\widehat\Pi$ 和 $\widehat\Pi^2=\widehat\Pi$：已经落在模型平面内的向量，再投影一次仍停留在原处。

</details>

<a id="section-05"></a>

## 线性模型中最小二乘计算的证明

$$
\widehat {\beta} _ {\mathbf {n}} = \underset {\beta \in \mathbb {R} ^ {d}} {\arg \min} R (\beta) \text{其中} R (\beta) = \frac {1}{n} \| \mathbf {Y} - \mathbf {X} \beta \| ^ {2}
$$

- 计算梯度：

$$
\frac {d}{d \beta} \left((\mathbf {Y} - \mathbf {X} \beta) ^ {T} (\mathbf {Y} - \mathbf {X} \beta)\right) = - 2 \mathbf {Y} ^ {T} \mathbf {X} + 2 \beta^ {T} \mathbf {X} ^ {T} \mathbf {X} \in \mathbb {R} ^ {1 \times d}
$$

- 凸函数极小点的一阶条件：

$$
-\mathbf {Y} ^ {T} + \beta^ {T} \mathbf {X} ^ {T} \mathbf {X} = 0
$$

> **译注：** 原课件该行漏了 $\mathbf Y^T$ 后的 $\mathbf X$。一阶条件应为 $-\mathbf Y^T\mathbf X+\beta^T\mathbf X^T\mathbf X=0$。

- 最终结果：$\widehat { \beta } _ { \mathfrak { n } } = ( \mathsf { X } ^ { T } \mathsf { X } ) ^ { - 1 } \mathsf { X } ^ { T } \mathsf { Y }$。

<a id="reading-normal-equation"></a>

把梯度写成列向量，最小二乘的一阶条件就是

$$
\nabla R(\beta)=\frac{2}{n}\mathbf X^T(\mathbf X\beta-\mathbf Y)=0
\quad\Longleftrightarrow\quad
\mathbf X^T\mathbf X\beta=\mathbf X^T\mathbf Y.
$$

因子 $1/n$ 不改变这一个目标函数的最小点；保留它的好处，是让不同样本量下的训练误差都按“每个样本平均”来理解。加入惩罚项之后，拟合项与惩罚项的相对比例就有意义了，届时不能只删去拟合项的 $1/n$ 而仍把同一个 $\lambda$ 当成相同的正则化强度。

这里可以通过线性方程得到显式的矩阵公式，通常称为闭式解。较一般的非线性学习问题往往需要迭代数值求解；具体采用什么损失，则由任务决定。

<a id="section-06"></a>

## 基于链式法则的另一种证明

- 设 $R ( \beta ) = \ell ( e ( \beta ) )$，其中 $\ell ( e ) = \| e \| ^ { 2 }$，且 $\boldsymbol { e } ( \beta ) = \boldsymbol { \mathsf { Y } } - \boldsymbol { \mathsf { X } } \beta$。
- 链式法则：$\frac { d R } { d \beta } = \frac { \partial \ell } { \partial e } \frac { \partial e } { \partial \beta }$，其中第 $j \mathrm { - t h }$ 个元素为：

$$
\frac {d R}{d \beta} [ j ] = \sum_ {k = 1} ^ {n} \frac {\partial \ell}{\partial e} [ k ] \frac {\partial e}{\partial \beta} [ k, j ]
$$

- 注意：$\frac { \partial \ell } { \partial e } = 2 e ^ { T } \in \mathbb { R } ^ { 1 \times n }$，且 $\frac { \partial e } { \partial \beta } = - { \pmb X } \in \mathbb { R } ^ { n \times d }$。
- 最后得到：$\frac{dR}{d\beta}=-2e^T\mathbf X=-2(\mathbf Y-\mathbf X\beta)^T\mathbf X$。

<a id="regression-risk"></a>

<a id="section-07"></a>

## 所有学生都（应该）知道的内容：回归中的偏差—方差权衡

<a id="reading-fixed-design-risk"></a>

下面先固定输入矩阵 $\mathbf X$，想象在这些输入位置反复观测带有独立噪声的新响应，每次重新拟合。$\mathbf h^*$ 是这些位置上的真实均值，$\widehat{\mathbf h}_n$ 随噪声和训练数据变化；期望衡量的是这种重复拟合的平均误差。

这里比较的是“估计出的均值”和“真实均值”，不是直接比较训练标签。若要预测相同输入位置上另一组独立、同方差的新标签，平均平方预测误差还会多出不可约噪声 $\sigma^2$。预测任意新输入时，也要结合新输入的分布，不能把本节的 $d/n$ 直接当成所有测试误差的公式。

- 模型：$\pmb { \mathsf { Y } } = \pmb { \mathsf { h } } ^ { * } + \varepsilon \in \mathbb { R } ^ { n }$。
- 最小二乘估计的计算：$\widehat { \mathbf { h } } _ { \mathbf { n } } = \widehat { \Pi } \mathbf { Y }$，其中 $\widehat { \Pi } = \pmb { \mathsf { X } } ( \pmb { \mathsf { X } } ^ { T } \pmb { \mathsf { X } } ) ^ { - 1 } \pmb { \mathsf { X } } ^ { T }$。
- 一种风险的定义：

$$
L (\widehat {\mathbf {h}} _ {\mathbf {n}}) = \frac {1}{n} \mathbb {E} \big (\| \mathbf {h} ^ {*} - \widehat {\mathbf {h}} _ {\mathbf {n}} \| ^ {2} \big)
$$

### 偏差—方差分解（1/2）：推导

- 首先注意到 $\widehat { \mathbf { h } } _ { \mathbf { n } } = \widehat { \Pi } \mathbf { Y } = \widehat { \Pi } ( \mathbf { h } ^ { * } + \varepsilon )$，于是

$$
\mathbf {h} ^ {*} - \widehat {\mathbf {h}} _ {\mathfrak {n}} = (I _ {n} - \widehat {\Pi}) \mathbf {h} ^ {*} - \widehat {\Pi} \varepsilon
$$

- 注意，$\widehat { \Pi } : \mathbb { R } ^ { n } \to \mathbb { R } ^ { n }$ 是到 $\mathcal { H } ( X )$ 上的正交投影。

$$
\widehat {\Pi} \circ \widehat {\Pi} = \widehat {\Pi}
$$

- 由于 $I _ { n } - { \widehat { \Pi } }$ 和 $\widehat { \Pi } .$ 的像空间正交：

$$
\begin{array}{r} L (\widehat {h} _ {n}) = \frac {1}{n} \mathbb {E} \big (\| \mathbf {h} ^ {*} - \widehat {\mathbf {h}} _ {\mathbf {n}} \| ^ {2} \big) \\ = \frac {1}{n} \mathbb {E} \big (\| (I _ {n} - \widehat {\Pi}) \mathbf {h} ^ {*} \| ^ {2} + \| \widehat {\Pi} \varepsilon \| ^ {2} \big) \end{array}
$$

### 偏差—方差分解（2/2）：结果

- 利用一个额外的技术结果（见下一页）：

$$
\begin{array}{r l} & L (\widehat {h} _ {n}) = \frac {1}{n} \mathbb {E} \big (\| \mathbf {h} ^ {*} - \widehat {\mathbf {h}} _ {\mathbf {n}} \| ^ {2} \big) \\ & \quad = \frac {1}{n} \mathbb {E} \big (\| (I _ {n} - \widehat {\Pi}) \mathbf {h} ^ {*} \| ^ {2} + \| \widehat {\Pi} \varepsilon \| ^ {2} \big) \\ & \quad = \underbrace {\frac {1}{n} \mathbb {E} \big (\| (I _ {n} - \widehat {\Pi}) \mathbf {h} ^ {*} \| ^ {2} \big)} _ {\text{偏差}} + \underbrace {\sigma^ {2} \frac {d}{n}} _ {\text{方差}} \end{array}
$$

- 用于模型选择，例如 AIC，即 Akaike Information Criterion（赤池信息准则）。

### d/n 项的解释

高斯随机向量投影的范数性质：

- 假设 $\mathbf { Z }$ 是 $\mathbb { R } ^ { n }$ 中服从 $ { \mathcal { N } _ { n } } ( 0 ,  { I _ { n } } )$ 的高斯随机向量，H 是 $\mathbb { R } ^ { n }$ 的线性子空间，$\Pi : \mathbb { R } ^ { n }  \mathbb { R } ^ { n }$ 是到 $\mathcal { H }$ 的线性投影。
- 则随机向量 $\Pi _ { \mathcal { H } } \mathbf { Z }$ 在 $\mathbb { R } ^ { n }$ 上服从高斯分布 $\mathcal { N } _ { n } ( 0 , \Pi )$（高斯随机向量的线性变换仍为高斯随机向量）。
- 此外，$\|\Pi Z\|^2$ 服从卡方分布，并且

$$
\mathbb {E} (\| \Pi \mathbf {Z} \| ^ {2}) = \dim (\mathcal {H})
$$

> **译注：** 上述性质要求正交投影。若投影子空间维度为 r，则平方范数服从自由度为 r 的卡方分布。

<a id="reading-variance-directions"></a>

### 每多拟合一个方向，就多接纳一份噪声

固定 $\mathbf X$ 后，投影把 $\mathbf h^*$ 分成能被模型表示的部分和无法表示的部分。后者形成上式的平方偏差。与此同时，$\widehat\Pi\varepsilon$ 把噪声中恰好沿模型方向的成分也保留下来，形成方差。

对于秩为 $d$ 的模型，每个正交方向贡献平均 $\sigma^2$ 的噪声能量，合计 $d\sigma^2$，再除以 $n$ 就是 $\sigma^2d/n$。在三个点的直线例子中，有常数方向和斜率方向两个自由方向，因此这一项为 $2\sigma^2/3$。若只拟合一个常数，则变成 $\sigma^2/3$，代价是可能无法表示真正的变化趋势。

<details>
<summary>推导：不用展开卡方密度也能得到 d/n</summary>

设 $\mathbf Q$ 的 $d$ 个列向量构成模型空间的一组标准正交基，则 $\widehat\Pi=\mathbf Q\mathbf Q^T$。噪声沿每个单位方向的投影方差都是 $\sigma^2$，所以

$$
\mathbb E\|\widehat\Pi\varepsilon\|^2
=\mathbb E\|\mathbf Q^T\varepsilon\|^2
=\sum_{j=1}^{d}\mathbb E(q_j^T\varepsilon)^2
=d\sigma^2.
$$

这个期望计算只需要零均值和协方差 $\sigma^2I_n$。高斯假设进一步给出 $\|\widehat\Pi\varepsilon\|^2/\sigma^2\sim\chi_d^2$。若模型矩阵的实际秩是 $r<d$，对应的自由方向数就是 $r$。

</details>

<a id="section-08"></a>

## 机器学习如何接续线性回归

1. 如果噪声不是加性的，会怎样？回归以外的任务呢？
2. 从线性模型到非线性模型。
3. 在非线性模型中，什么量替代维度 d 来衡量复杂度？
4. d/n 的速率对更大的假设类是否也具有代表性？如果 d 大于 n 呢？

<a id="section-09"></a>

## 从经典统计到机器学习

- 处理高维模型：

$$
d \gg 1, d \gg n
$$

- 重新审视维度：

参数个数与函数集合复杂度的比较。

<a id="reading-high-dimensional-regimes"></a>

这里有两种不同的“大”。$d$ 本身大，会增加存储和计算量；$d$ 相对 $n$ 大，则意味着需要估计的量很多、观测提供的约束很少。例如，同样是 3,000 个变量，配 100,000 条观测和配 100 条观测，是很不一样的问题。

在线性模型中，独立的特征方向数可以直接用矩阵的秩表达；若列之间冗余，参数个数就已经不等于独立方向数。推广到更一般的函数族后，复杂度还受参数约束、函数结构等因素影响，不能只数有多少个参数。

<a id="section-10"></a>

## 高维插曲：一个令人意外的事实

![image](<Images/02_LM/image_003.jpg>)

99%

- 外壳与总体积之比：

$$
\frac {v o l (B _ {d} (0 , 1) - B _ {d} (0 , 1 - \varepsilon))}{v o l (B _ {d} (0 , 1))} = 1 - (1 - \varepsilon) ^ {d} \rightarrow 1 \text{当} d \rightarrow \infty
$$

### 综述性观点文章

D. Donoho（2000），High Dimensional Data Analysis: The Curses and Blessings of Dimensionality（高维数据分析：维度的诅咒与馈赠）。

### 数学著作

Roman Vershynin（2018），High-Dimensional Probability（高维概率）。

<a id="reading-orange-shell"></a>

### 同样厚度的“橘子皮”，在高维里占多少体积

把半径设为 $1$，外壳厚度设为 $\varepsilon=0.005$，内球半径就是 $0.995$。半径缩小到原来的 $0.995$ 倍，$d$ 维体积会缩小到原来的 $0.995^d$ 倍。因此不必知道单位球体积的具体常数，也能算出：

| 维度 | 外壳所占比例 $1-0.995^d$ |
|---|---:|
| $d=2$ | 约 $1.00\%$ |
| $d=3$ | 约 $1.49\%$ |
| $d=1000$ | 约 $99.33\%$ |

若从球内按体积均匀采样，落进外壳的概率就等于这个比例。高维中的薄外壳可以容纳绝大多数样本，二维、三维画图形成的直觉因此需要重新检查。这个计算描述的是球的体积和相应均匀采样；真实数据也可能集中在低维结构上，其分布仍要由具体问题决定。

<a id="section-11"></a>

## 从经典统计到机器学习：处理高维问题

A. 稀疏性与线性模型。

B. 估计非线性函数。

C. 推广。

<a id="section-12"></a>

## 对线性回归而言，“高维”意味着什么

- 到目前为止，假设 $n \geq d$ 且 $( \pmb { \mathsf { X } } ) = d$。
- 当 d 增大时，可能或将会出现两种情况：
- 计算逆矩阵 $( { \pmb X } ^ { T } { \pmb X } ) ^ { - 1 }$ 时不稳定。
- 数据矩阵 X 秩亏。
- 秩亏情形（但仍有 $n \geq d )$）：
- 最小二乘问题存在多个解……
- 在投影矩阵中使用 Moore–Penrose 伪逆来代替 $( { \pmb X } ^ { T } { \pmb X } ) ^ { - 1 }$，可得到一个最小二乘估计。
- 这个最小二乘估计是使 $\ell _ { 2 } { \mathrm { - } } \mathsf { n o r m }$ 最小的解。
- 对不稳定性的补救：使用（岭）正则化……

<a id="reading-rank-and-stability"></a>

### 解不唯一，与解对扰动敏感

先看两列完全重复的例子：

$$
\mathbf X=\begin{pmatrix}1&1\\2&2\end{pmatrix},
\qquad
\mathbf Y=\begin{pmatrix}2\\4\end{pmatrix}.
$$

任何满足 $\beta_1+\beta_2=2$ 的系数都能完全拟合数据，$(2,0)$、$(1,1)$、$(0,2)$ 都是解。观测只能识别两个系数的和，无法区分各自的贡献。伪逆选出的最小范数解是 $(1,1)$；它给出一种确定的选择，却不会凭空恢复数据中没有的信息。虽然系数不唯一，训练点上的最优预测向量仍是唯一的正交投影。

再看一个仍然可逆、但很敏感的例子：

$$
\mathbf X=\begin{pmatrix}1&1\\1&1.01\end{pmatrix}.
$$

响应 $(2,2.01)^T$ 对应解 $(1,1)^T$；只把第二个响应增加 $0.01$，改成 $(2,2.02)^T$，解就变成 $(0,2)^T$。两列非常接近，数据很难可靠地区分它们，于是很小的观测变化就能引起很大的系数变化。

当 $d>n$ 时，$\operatorname{rank}(\mathbf X)\leq n<d$，列满秩必然不成立；当 $d\leq n$ 时，也可能因为重复或近似重复的列出现上述问题。实际计算最小二乘通常求解相应线性系统，采用 QR 或 SVD 等分解；显式写出的逆矩阵主要帮助推导。

<a id="section-13"></a>

## A. 稀疏性与线性模型：调整模型维度

- 向量记号：

响应向量 $\mathbf { Y } \in \mathbb { R } ^ { n }$，输入数据矩阵 $\textsf { X } ( { \mathsf { s i z e } } \ n \times d )$。

- 以向量形式表示的线性模型：

$$
\mathbf {Y} = \mathbf {X} \boldsymbol {\beta} ^ {*} + \varepsilon
$$

其中 ε 是均值为零、与 X 独立的随机噪声向量。

<a id="section-14"></a>

## 稀疏线性回归模型

- 直觉：如果模型中的某些变量不提供信息，但我们不知道具体是哪些变量，会怎样？
- 稀疏性假设：设真实参数 $\beta ^ { * }$ 仅涉及一部分变量，这个变量子集称为支撑集。

$$
m ^ {*} = \{j: \beta_ {j} ^ {*} \neq 0 \} \subset \{1, \dots , d \}
$$

任意 β 的 $\ell _ { 0 }$“范数”：$\| \beta \| _ { 0 } = \sum _ { j = 1 } ^ { d } \mathbb { I } \{ \beta _ { i } \neq 0 \}$。

<a id="reading-sparse-support"></a>

### 稀疏性难在“不知道该留下哪些变量”

例如 $\beta=(2,0,-1,0)^T$ 的支撑集为 $\{1,3\}$，只有第一、第三个特征进入预测。此时

$$
\|\beta\|_0=2,\qquad \|\beta\|_1=3,\qquad \|\beta\|_2^2=5.
$$

$\ell_0$ 统计非零系数的个数；上方求和中的指标应一致地理解为 $\sum_{j=1}^d\mathbb I\{\beta_j\neq0\}$。它通常被称为“零范数”，但不满足范数的齐次性：把所有非零系数放大两倍，计数仍然是 $2$。

如果事先知道 100 个变量中哪 20 个有用，就可以取出相应的 20 列，再拟合这个较小的模型。稀疏学习通常只假设有用变量较少，具体位置仍未知，因此需要同时处理“选择支撑集”和“估计系数”两个问题。即使支撑集已知，有限样本下的估计误差仍然存在。

<a id="section-15"></a>

## 两种表述：约束优化与惩罚优化

1. Ivanov 表述：在 $0$ 与 min $\{ n , d \}$ 之间选取 k。

$$
\min _ {\beta \in \mathbb {R} ^ {d}} \| \mathbf {Y} - \mathbf {X} \beta \| _ {2} ^ {2} \quad \text{满足} \| \beta \| _ {0} \leq k
$$

2. Tikhonov 表述：取 $\lambda > 0$。

$$
\min _ {\beta \in \mathbb {R} ^ {d}} \left\{\| \mathbf {Y} - \mathbf {X} \beta \| _ {2} ^ {2} + \lambda \| \beta \| _ {0} \right\}
$$

- Tikhonov 表述看起来是 Ivanov 表述的拉格朗日形式。
- 但由于 $\ell _ { 0 }$ 范数缺乏光滑性，这里的两种表述并不等价。

> **译注：** 原文将不等价归因于“不光滑”，这个归因不充分。这里的关键是非凸性及离散的支撑选择；非光滑的凸问题在适当条件下仍可以建立约束形式与惩罚形式的对应。

- 带 $\ell _ { 0 }$ 约束的 Ivanov 表述称为最佳子集选择问题。已有基于启发式的算法，例如前向逐步回归，在 $k \simeq 3 5$ 以内效果尚可。近期进展：参见 Bertsimas 等（2016）的混合整数优化（MIO）表述。
- 从现在起重点讨论 Tikhonov 正则化。

<a id="reading-budget-and-price"></a>

### 一个限制数量，一个给每个变量定价

约束形式规定“最多使用 $k$ 个变量”，然后在这个限制内尽量拟合。惩罚形式则为每个非零系数收取 $\lambda$ 的代价：若增加一个变量、重新拟合后减少的残差平方和超过 $\lambda$，它才值得被加入。

<details>
<summary>例子：为什么调整 λ 不一定能得到每一种最优模型大小</summary>

假设分别使用 $0,1,2$ 个变量时，能达到的最小残差平方和是 $10,9,0$。约束“最多一个变量”会选残差为 $9$ 的单变量模型。

惩罚形式中，这三个候选的目标值为 $10$、$9+\lambda$ 和 $2\lambda$。要让中间那个最优，必须同时满足

$$
9+\lambda\leq10\quad\text{和}\quad9+\lambda\leq2\lambda,
$$

也就是 $\lambda\leq1$ 且 $\lambda\geq9$，不可能同时成立。因此，给定数量上限能够选出的模型，未必能通过某个统一的变量价格选出来。这是离散、非凸模型选择中两种表述未必等价的具体表现。

</details>

<a id="section-16"></a>

## 稀疏性与线性模型：模型选择

### 建立联系：Tikhonov 惩罚与方差

回顾：

- 带 $\ell _ { 0 }$ 惩罚的 Tikhonov 表述：取 $\lambda > 0$。

$$
\min _ {\beta \in \mathbb {R} ^ {d}} \left\{\| \mathbf {Y} - \mathbf {X} \beta \| _ {2} ^ {2} + \lambda \| \beta \| _ {0} \right\}\tag{1}
$$

- 最小二乘估计 ${ \widehat { \beta } } \mathbf { : }$ 的误差偏差—方差分解：

$$
\frac {1}{n} \mathbb {E} \big (\| \mathbf {X} \beta^ {*} - \mathbf {X} \widehat {\beta_ {\mathbf {n}}} \| ^ {2} \big) \simeq \text{偏差} + \sigma^ {2} \frac {d}{n}\tag{2}
$$

其中 d 是数据维度，$\sigma ^ { 2 }$ 是高斯噪声的方差。

现在的问题：偏差—方差分解（2）能否解释（1）？这个惩罚项是否正确？

<a id="section-17"></a>

## 线性模型中的模型选择

- 模型：$\mathbf Y=\mathbf X\beta^*+\varepsilon$。
- 考虑 $\beta ^ { * }$ 的一个模型：它由 $\{ 1 , \ldots , d \}$ 的索引子集 m 给出。
- 例子：在维度 $d = 3$ 下，有：
- 1 个大小为 $| m | = 0 ;$ 的模型：常数模型。
- 3 个大小为 $| m | = 1 ; \{ 1 \} , \{ 2 \} , \{ 3 \}$ 的模型。
- 3 个大小为 $| m | = 2 \colon \{ 1 , 2 \} , \{ 2 , 3 \} , \{ 1 , 3 \}$ 的模型。
- 1 个大小为 $| m | = 3 \colon \{ 1 , 2 , 3 \}$ 的模型。

可能有 8 个版本的最小二乘估计，称为约束最小二乘估计（$| m | = 3$ 的情形除外，它没有约束）。

<a id="section-18"></a>

## 线性模型中的模型选择

- 考虑索引 $\{ 1 , \ldots , d \}$ 中变量子集 m 的集合 $\mathcal { M }$，这样的集合 m 共有 $2 ^ { d }$ 个。
- 对每个 $m \in { \mathcal { M } }$，有一个维度为 $| m |$ 的标准线性回归模型。换言之，对那些 $j \notin m _ { \cdot }$，有 $\theta _ { j } ^ { * } = 0$。
- 用 $\mathsf { X } _ { m }$ 表示 X 的一个大小为 $n \times | m |$ 的子矩阵，它只包含索引属于 m 的列。
- 对每个模型 $m \in { \mathcal { M } }$，计算约束最小二乘估计 $\widehat { \theta } _ { n } ^ { ( m ) } = ( \mathsf { X } _ { m } ^ { T } \mathsf { X } _ { m } ) ^ { - 1 } \mathsf { X } _ { m } ^ { T } \mathsf { Y } \in \mathbb { R } ^ { | m | }$。
- 最终估计量是在所有 $m \in { \mathcal { M } }$ 上的 ${ \widehat { \theta } } _ { n } ^ { ( m ) }$ 中选出的“最佳”估计量。
- 用 $\mathsf { X } _ { m }$ 表示大小为 $n \times | m |$ 的数据矩阵。
- 预测器的风险：$r _ { m } = \frac { 1 } { n } \mathbb { E } \big ( \| \mathbf { X } \theta ^ { * } - \mathbf { X } _ { m } \widehat { \theta } _ { n } ^ { ( m ) } \| ^ { 2 } \big )$。
- 理论上的最佳估计量（称为预言机）：

$$
\widehat {\theta} _ {n} ^ {(\overline {{m}})} \quad \text{其中} \quad \overline {{m}} = \underset {m \in \mathcal {M}} {\arg \min} r _ {m}
$$

- 使用赤池信息准则（AIC）的惩罚最小二乘：

$$
\widehat {m} = \underset {m \in \mathcal {M}} {\arg \min} \left\{\| \mathbf {Y} - \mathbf {X} _ {m} \widehat {\theta} _ {n} ^ {(m)} \| ^ {2} + 2 | m | \sigma^ {2} \right\}
$$

（假设 $\sigma ^ { 2 }$ 已知，则可由数据计算。）

<a id="reading-aic-example"></a>

### 用一个可计算的分数近似比较模型

“预言机”知道真实预测风险，因而知道哪个子模型最好；实际拿到的只有样本，无法直接使用这个答案。若只比较训练残差，较大的嵌套模型总能做到不差于较小模型，因为新增系数至少可以取零。于是需要为增加自由度付出代价。

以课件中已知 $\sigma^2$ 的高斯线性模型为例，令 $\sigma^2=1$，并假设几个候选模型得到以下残差平方和：

| 模型大小 $\lvert m\rvert$ | 残差平方和 | 惩罚 $2\lvert m\rvert\sigma^2$ | 总分 |
|---:|---:|---:|---:|
| 0 | 40 | 0 | 40 |
| 1 | 24 | 2 | 26 |
| 2 | 21 | 4 | 25 |
| 3 | 20 | 6 | 26 |

这里会选择大小为 $2$ 的模型。第三个变量只把残差从 $21$ 降到 $20$，不足以抵消增加的惩罚 $2$。这解释了为什么“训练拟合更好”和“被模型选择准则选中”是两回事。下文推导说明这个系数 $2\sigma^2$ 从哪里来。

原例把 $|m|=0$ 称为常数模型，通常是把截距单独保留，不纳入待选变量。如果连截距也不单独设置，所有系数为零对应的就是零函数。比较模型时应始终使用同一种截距约定。

<a id="section-19"></a>

## 选读材料：赤池信息准则的推导

<details>
<summary>展开完整推导：从投影误差到模型选择准则</summary>

### 线性回归中的最小二乘估计

- 用 $\mathsf { X } _ { m }$ 表示数据矩阵 $( n \times | m | )$，用 ${ \widehat { \theta } } _ { n } ^ { ( m ) }$ 表示最小二乘估计。
- 预测向量：$\mathsf { X } _ { m } \widehat { \theta } _ { n } ^ { ( m ) } = \mathsf { X } _ { m } ( \mathsf { X } _ { m } ^ { T } \mathsf { X } _ { m } ) ^ { - 1 } \mathsf { X } _ { m } ^ { T } \mathsf { Y } = \widehat { \Pi } _ { m } \mathsf { Y }$。

![image](<Images/02_LM/image_004.jpg>)

### 偏差—方差分解（1/2）：推导

- 注意，$\widehat { \Pi } _ { m } : \mathbb { R } ^ { n }  \mathbb { R } ^ { n }$ 是到 m 中各方向所张成空间的正交投影：

$$
\widehat {\Pi} _ {m} \circ \widehat {\Pi} _ {m} = \widehat {\Pi} _ {m}
$$

- 有 $\mathbf X_m\widehat\theta_n^{(m)}=\widehat\Pi_m\mathbf Y=\widehat\Pi_m(\mathbf X\theta^*+\varepsilon)$，于是

$$
\mathbf {X} \theta^ {*} - \mathbf {X} _ {m} \widehat {\theta} _ {n} ^ {(m)} = (I _ {n} - \widehat {\Pi} _ {m}) \mathbf {X} \theta^ {*} - \widehat {\Pi} _ {m} \varepsilon
$$

- 投影算子的性质：$I _ { n } - \widehat { \Pi }$ 和 $\widehat { \Pi }$ 的像空间正交。
- 因此：

$$
\begin{array}{r l} {r _ {m}} & {= \frac {1}{n} \mathbb {E} \left(\| (I _ {n} - \widehat {\Pi} _ {m}) \mathbf {X} \theta^ {*} \| ^ {2} + \| \widehat {\Pi} _ {m} \varepsilon \| ^ {2}\right)} \\ & {= \frac {1}{n} \mathbb {E} \left(\| (I _ {n} - \widehat {\Pi} _ {m}) \mathbf {X} \theta^ {*} \| ^ {2}\right) + \sigma^ {2} \frac {| m |}{n}} \end{array}
$$

因为 $\| \widehat { \Pi } _ { m } \varepsilon \| ^ { 2 }$ 服从自由度为 $| m |$ 的卡方分布（多元高斯向量投影的性质）。

### 赤池信息准则（1/2）：推导

- 类似地，可以推导出：

$$
\frac {1}{n} \mathbb {E} \big (\| \mathbf {Y} - \mathbf {X} _ {m} \widehat {\theta} _ {n} ^ {(m)} \| ^ {2} \big) = \frac {1}{n} \mathbb {E} \big (\| (I _ {n} - \widehat {\Pi} _ {m}) \mathbf {X} \theta^ {*} \| ^ {2} \big) + \sigma^ {2} \frac {(n - | m |)}{n}
$$

事实上，$\begin{array} { r } { \mathsf { \pmb { Y } } - \mathsf { \pmb { X } } _ { m } \widehat { \theta } _ { n } ^ { ( m ) } = \big ( I _ { n } - \widehat { \Pi } _ { m } \big ) ( \mathsf { \pmb { X } } \theta ^ { * } + \varepsilon ) } \end{array}$，且 $\| I _ { n } - \widehat { \Pi } _ { m } \varepsilon \| ^ { 2 }$ 服从自由度为 $n - | m |$ 的卡方分布。

- 联合这两个恒等式，可将预测误差与风险联系起来：

$$
\frac {1}{n} \mathbb {E} \big (\| \mathbf {Y} - \mathbf {X} _ {m} \widehat {\theta} _ {n} ^ {(m)} \| ^ {2} \big) = r _ {m} + \sigma^ {2} \frac {(n - 2 | m |)}{n}
$$

### 赤池信息准则（2/2）：误差的经验估计量

- 已经得到：

$$
r _ {m} = \frac {1}{n} \mathbb {E} \big (\| \mathbf {Y} - \mathbf {X} _ {m} \widehat {\theta} _ {n} ^ {(m)} \| ^ {2} \big) + \sigma^ {2} \frac {(2 | m | - n)}{n}
$$

- 误差的无偏估计量（假设方差已知）：

$$
\widehat {r} _ {m} = \frac {1}{n} \| \mathbf {Y} - \mathbf {X} _ {m} \widehat {\theta} _ {n} ^ {(m)} \| ^ {2} + \sigma^ {2} \frac {(2 | m | - n)}{n}
$$

- 赤池信息准则：

$$
\widehat {m} = \underset {m \in \mathcal {M}} {\arg \min} \left\{\| \mathbf {Y} - \mathbf {X} _ {m} \widehat {\theta} _ {n} ^ {(m)} \| ^ {2} + 2 | m | \sigma^ {2} \right\}
$$

选读材料结束。

这里的卡方变量应写成 $\|\widehat\Pi_m\varepsilon\|^2/\sigma^2$ 和 $\|(I_n-\widehat\Pi_m)\varepsilon\|^2/\sigma^2$；原页分别省略了方差归一化，并在第二处漏写投影括号。相应期望仍是 $|m|\sigma^2$ 与 $(n-|m|)\sigma^2$。上述固定模型的无偏风险估计，去掉对所有候选都相同的常数、再乘以 $n$，便得到正文采用的残差平方和加 $2|m|\sigma^2$ 的选择准则。

</details>

<a id="section-20"></a>

## 高维情况下的 AIC

- 当 d 很大时，这样做是否实用？
- 最坏情况下，需要遍历大约 $e ^ { d / 2 }$ 个模型，其中 $| m | \simeq d / 2 .$。

<a id="reading-subset-complexity"></a>

真正增长的是需要比较的变量组合数。总共 $d$ 个变量有 $2^d$ 个子集，固定选择 $k$ 个时则有 $\binom dk$ 种。仅从 100 个变量中选 20 个，就约有 $5.36\times10^{20}$ 种组合。

上方 $e^{d/2}$ 表达的是指数规模的直觉；更准确地说，最大的二项式系数出现在 $k$ 接近 $d/2$ 的位置，其量级为 $2^d/\sqrt{\pi d/2}$。此外，遍历更多候选也更容易偶然找到迎合噪声的模型，固定模型的自由度惩罚并没有自动解决所有大规模搜索带来的选择偏差。

<a id="section-21"></a>

## A. 稀疏性与线性模型：从数理统计到优化

### 解决计算负担：凸性的力量

实用的模型选择方法主要是贪心启发式方法，每次增加和／或移除一个变量，以探索整个模型空间的一部分；整个模型空间的规模随维度呈指数增长。例子包括前向逐步回归、前向—后向算法等。

- 问题：是否能够同时针对未知参数 $\beta$ 及其支撑索引子集进行优化？
- 答案是肯定的，代价是进行所谓的松弛：把带 $\ell _ { 0 }$ 惩罚的非凸表述替换为带 $\ell _ { 1 }$ 惩罚的凸化问题。

<a id="lasso"></a>

<a id="reading-greedy-and-convexity"></a>

前向逐步选择每次尝试加入一个变量，并对当前候选重新拟合。它沿着一条路径探索，能节省枚举成本，却可能错过必须把两个变量一起考虑才显现出来的组合。

把 $\ell_0$ 换成 $\ell_1$，则改变了优化问题本身：平方残差和绝对值之和都对 $\beta$ 凸，因此整体仍是凸问题。得到的惩罚允许系数连续变化，同时保留把部分系数推到零的能力。它是另一种可计算的稀疏建模办法，并不保证给出与逐个枚举最佳子集完全相同的答案。

<a id="section-22"></a>

## 线性模型的 LASSO：从 $\ell _ { 0 }$ 到 $\ell _ { 1 }$

- 考虑对前述问题作松弛，用 $\ell _ { 1 } { \mathrm { - } } \mathsf { n o r m }$ 替代 $\ell _ { 0 } - \mathsf { n o r m }$。

$$
\| \beta \| _ {1} = \sum_ {j = 1} ^ {d} | \beta_ {j} |
$$

- 新估计量称为 ${ \mathsf { L } } { \mathsf { A } } { \mathsf { S } } { \mathsf { S } } { \mathsf { O } }$：对任意 $\lambda > 0$，

$$
\widehat {\beta} _ {\lambda} \in \underset {\beta \in \mathbb {R} ^ {d}} {\arg \min} \left\{\| \mathbf {Y} - \mathbf {X} \beta \| ^ {2} + \lambda \| \beta \| _ {1} \right\}
$$

- 通过构建所谓正则化路径 $\lambda  \widehat { \beta } _ { \lambda }$ 的高效算法求近似解。

![image](<Images/02_LM/image_005.jpg>)

- 理论依据：可以证明，当 $n , d \to \infty$ 时，

$$
\frac {1}{n} \mathbb {E} \big (\| \mathbf {X} \beta^ {*} - \mathbf {X} \widehat {\beta} \| ^ {2} \big) \leq C \| \beta^ {*} \| _ {1} \sqrt {\frac {\log d}{n}}
$$

<a id="reading-lasso-threshold"></a>

### 绝对值惩罚怎样把系数压到零

先把问题缩小到一个系数，并沿用本节没有 $1/2$ 的平方损失：

$$
\min_b (z-b)^2+\lambda|b|.
$$

当 $b>0$ 时，令导数 $2(b-z)+\lambda=0$，得到 $b=z-\lambda/2$；当 $b<0$ 时，得到 $b=z+\lambda/2$。如果 $z$ 的绝对值不超过 $\lambda/2$，最优值就停在 $b=0$。合起来是

$$
\widehat b_{\mathrm{LASSO}}
=\operatorname{sign}(z)\bigl(|z|-\lambda/2\bigr)_+,
\qquad (u)_+=\max(u,0).
$$

较小的信号直接归零，较大的信号也会向零缩短 $\lambda/2$，这叫软阈值。绝对值函数在零点有尖角，使一整段 $z$ 都可以对应同一个零解；下面的一维练习还会把它与另外两种惩罚画在一起比较。

取 $\mathbf X=I_3$、$\mathbf Y=(3,0.4,-2)^T$、$\lambda=2$，三个坐标可以分别求解，得到

$$
\widehat\beta_{\mathrm{LASSO}}=(2,0,-1)^T.
$$

第二个特征被剔除，另外两个仍保留，但系数绝对值也减小了。这个逐坐标公式适用于这里的正交设计；一般的相关特征会相互影响，需要联合求解。

从几何上看，二维 $\ell_1$ 约束集是带尖角的菱形，角点落在坐标轴上，优化时容易在这样的地方接触到损失等高线；坐标落在轴上，就意味着一个系数为零。系数路径则展示了改变 $\lambda$ 时，这些坐标怎样进入或离开解。[LASSO 与系数路径](https://cs229.stanford.edu/notes2021fall/lecture10-lasso-regression.pdf)

<details>
<summary>推导：零点的最优条件，以及理论界中的 log d</summary>

$|b|$ 在零点不可微，但其子梯度是区间 $[-1,1]$。零点成为最优解的条件是

$$
0\in-2z+\lambda[-1,1],
$$

即 $|z|\leq\lambda/2$。一般 LASSO 中，对第 $j$ 列 $\mathbf X_j$，零系数的条件相应为

$$
|2\mathbf X_j^T(\mathbf Y-\mathbf X\widehat\beta)|\leq\lambda.
$$

它比较该特征与剩余残差的相关程度，解释了为什么特征之间的关系会改变哪些系数被选中。

正文所列预测误差界，把维度依赖写成 $\sqrt{\log d/n}$。例如 $d=n^3$ 时，$\log d/n=3\log n/n\to0$，即使变量数超过样本数，这一因子仍可能趋于零。要让整项误差界变小，还要控制 $\|\beta^*\|_1$，并满足相应设计矩阵归一化、噪声及 $\lambda$ 选择条件；常数 $C$ 也包含模型假设的信息。预测误差小与准确恢复每个非零系数的支撑集，是不同的结论。

</details>

<a id="section-23"></a>

## 机器学习算法之“母”：惩罚优化

- 将学习过程写成对依赖于数据的准则的优化：

准则(h) = 训练误差(h) + λ 惩罚(h)。

- 训练误差：与损失函数相关的数据拟合项。
- 惩罚项：决策函数的复杂度。
- 常数 λ：通过交叉验证过程调整的平滑参数。

<a id="reading-regularization-purpose"></a>

### 为什么愿意牺牲一点训练拟合

有限数据里既有规律，也有偶然波动。一个很灵活的模型可以把两者一起拟合，因此训练误差很小，并不意味着对新数据也准确。正则化把“拟合好”与“采用较简单或较稳定的解”放在同一个目标里比较。

$\lambda$ 控制惩罚在目标中的分量；学习率控制数值算法每一步怎样更新参数。改变 $\lambda$ 会改变要求解的问题，改变学习率主要影响怎样到达这个问题的解。标准化则是在拟合前调整特征的尺度，三者各有作用。

<details>
<summary>例子：同样三个点，训练误差为零的曲线怎样变化</summary>

对前面的三个点，直线 $\widehat h(t)=2+1.5t$ 的残差平方和为 $1.5$。二次曲线 $q(t)=1+1.5t+1.5t^2$ 能穿过全部三个点，训练残差为零；但在 $t=2$ 处，二者分别预测 $5$ 和 $10$。仅凭这三个观测，不能确认哪一个外推更好。

现在把中间的响应从 $1$ 改成 $1+\Delta$。重新拟合后，直线在 $t=2$ 处的预测变为 $5+\Delta/3$，插值二次曲线的预测变为 $10-3\Delta$。在这个位置，后者把同一个观测扰动放大得更多。这个计算说明模型灵活性怎样让有限样本中的波动进入预测；是否发生过拟合，还要通过未参与拟合的数据来判断。

</details>

<details>
<summary>延伸：显式惩罚以外的正则化思路</summary>

对输入施加适当的小扰动，并要求预测仍保持合理，是另一种限制模型过度依赖细节的办法。Dropout 则在训练时随机屏蔽部分单元，使模型不能总依赖某一条固定的协作路径。它们与本讲的共同点，是限制模型怎样利用训练样本；具体效果取决于任务、扰动方式和训练过程，不能把“增加任何噪声”都理解成改进学习。

结构选择和参数估计也可以相互影响，例如在训练中探索不同的子模型。这里先用线性模型和明确的惩罚项，把这种关系写成可以直接分析的优化问题。

</details>

<a id="section-24"></a>

## A. 稀疏性与线性模型：结构化稀疏性

### 将人的先验放进惩罚项：稀疏模式

![image](<Images/02_LM/image_006.jpg>)

### 最简单的结构化惩罚：Group LASSO

- 参数 $\beta ^ { * }$ 的分组结构：设 G 是 $\{ 1 , \ldots , d \}$ 中索引子集的分组数。对 $g = 1 , \ldots , G$，用 $\mathbf { \boldsymbol { x } } ( \bar { g } )$ 表示 X 中由第 $\boldsymbol { g }$ 组变量组成的子矩阵，用 $\beta ^ { ( g ) }$ 表示施加于第 $\boldsymbol { g }$ 组变量的系数向量；$d _ { g }$ 是第 g 组的大小。
- Group LASSO 表述：

$$
\widehat {\beta} _ {\lambda} \in \underset {\beta \in \mathbb {R} ^ {d}} {\arg \min} \left\{\| \mathbf {Y} - \mathbf {X} \beta \| ^ {2} + \lambda \sum_ {g = 1} ^ {G} \sqrt {d _ {g}} \| \beta^ {(g)} \| \right\}
$$

![image](<Images/02_LM/image_007.jpg>)

<a id="reading-group-lasso"></a>

### 选择一个组，而不只选择一个坐标

变量往往有事先已知的分组：客户资料与交易历史是两类信息，一组传感器的多个通道或一组相关基因也可以作为一个整体。普通 LASSO 只看到一串坐标，分组信息需要通过惩罚项告诉模型。

Group LASSO 先计算每组的欧氏长度 $\|\beta^{(g)}\|_2$，再把各组长度加起来。整个组向量变成零，就意味着这组特征一起退出预测。例如两组系数为 $(3,4)$ 和 $(0,0)$ 时，未加权的组惩罚是 $5+0$；非零组内的方向仍可以连续调整。

因此，它鼓励“组间稀疏”，不会专门鼓励每个非零组内部也很稀疏；一个组被保留，也不意味着其中每个系数都被强制设为非零。课件中的 $\sqrt{d_g}$ 用来调整不同组大小的惩罚权重，而组内采用的是 $\ell_2$ 范数，保留外面的平方根。

<details>
<summary>延伸：怎样同时选择组和组内变量</summary>

对于互不重叠、覆盖全部变量的分组，如果直接把组内 $\ell_2$ 改成 $\ell_1$，则

$$
\sum_g\|\beta^{(g)}\|_1=\|\beta\|_1.
$$

这会退回普通 LASSO；若保留不同组权重，则是加权 LASSO，并不会自动产生独立的组选择机制。要同时鼓励整组归零和组内坐标归零，可以叠加两种惩罚：

$$
\lambda_1\sum_g\sqrt{d_g}\|\beta^{(g)}\|_2
+\lambda_2\|\beta\|_1.
$$

这种组合称为 Sparse Group LASSO。[Friedman、Hastie 与 Tibshirani 的原文说明](https://arxiv.org/abs/1001.0736)

</details>

- 强制时间上的一致性，会引入如下惩罚项：

$$
\widehat {\beta} _ {\lambda} \in \underset {\beta \in \mathbb {R} ^ {d}} {\arg \min} \left\{\| \mathbf {Y} - \mathbf {X} \beta \| ^ {2} + \lambda \| \beta \| _ {1} + \mu \sum_ {j = 2} ^ {d} | \beta_ {j} - \beta_ {j - 1} | \right\}
$$

<a id="ridge"></a>

<a id="reading-fused-lasso"></a>

### 相邻位置也可以成为模型的一部分

普通 LASSO 对各列的惩罚相互独立。如果把数据列和对应系数一起重新排序，目标值不变，因此它本身不知道哪些变量相邻。时间序列、空间位置或序列中的相邻位点，则可能需要保留这种顺序信息。

上式额外惩罚 $\sum_{j=2}^d|\beta_j-\beta_{j-1}|$，称为 fused LASSO 的相邻差分惩罚。比较两个向量：

$$
\beta^{(A)}=(0,0,3,3,3,0),\qquad
\beta^{(B)}=(0,3,0,3,0,3).
$$

两者都有三个非零系数，$\ell_1$ 范数也都是 $9$，但相邻差分绝对值之和分别为 $6$ 和 $15$。在拟合项相同的情况下，新的惩罚更偏好连续成段的 A。$\lambda$ 调节系数本身向零收缩的程度，$\mu$ 调节相邻跳变的代价，从而鼓励一段一段保持相同系数。

<details>
<summary>延伸：把已有知识写进优化目标</summary>

分组和邻接关系都是建模知识。类似地，如果候选函数应满足某个物理方程，可以把它代入方程，计算方程残差，再把该残差与数据拟合误差一起最小化；物理信息神经网络采用的就是这类思路。[相关研究](https://arxiv.org/abs/1711.10561)

建模时首先要决定希望解遵守什么关系，再考虑如何求解相应优化问题。用有限权重惩罚违反关系的程度，通常表达的是软约束；若要求某种关系严格成立，还需要合适的约束或结构设计。数据噪声、方程近似和两者的权重都会影响最后得到的解。

</details>

<a id="section-25"></a>

## A. 稀疏性与线性模型：岭回归

### 惩罚优化：其他惩罚项？

- 到目前为止：由线性函数 $h \in \mathcal H$ 构成的假设类，以及诱导稀疏性的各种惩罚项。

$$
\text{准则} (h) = \text{训练误差} (h) + \lambda \text{惩罚项} (h)
$$

- 这个思想可追溯到 20 世纪 60 年代（Ivanov、John、Lavrent’ev、Tikhonov），当时惩罚项被用作不适定问题解的正则化器。

<a id="section-26"></a>

## 统计中的不适定问题：高维最小二乘回归

- 假设 d 大于 n。
- 求解最小二乘优化问题时，可以看到方程数少于变量数：这就是欠定线性系统的情形。
- 另一种说法是，$\mathbf X^T\mathbf X$ 不满秩，因而不可逆，并且有无穷多个解。

<a id="reading-underdetermined"></a>

当 $d>n$ 时，至少有 $d-n$ 个独立的参数方向无法被 $\mathbf X$ 区分。若 $\mathbf v\neq0$ 且 $\mathbf X\mathbf v=0$，那么 $\beta$ 与 $\beta+\mathbf v$ 在所有训练点上的预测完全相同。

无穷多个最小二乘解总是存在于这种非满列秩情形；至于能否把训练残差降到零，还要看 $\mathbf Y$ 是否属于 $\mathbf X$ 的列空间。特别地，若 $\mathbf X$ 满行秩，则列空间等于 $\mathbb R^n$，任意响应都可以被完全拟合。正则化给这些数据无法区分的解增加了选择依据。

<a id="section-27"></a>

## 统计中最早的正则化方法：岭回归

- Ridge 估计量是下列惩罚优化问题的解：对任意 $\lambda > 0$，

$$
\widehat {\beta} _ {\lambda} \in \underset {\beta \in \mathbb {R} ^ {d}} {\arg \min} \left\{\| \mathbf {Y} - \mathbf {X} \beta \| ^ {2} + \lambda \| \beta \| _ {2} ^ {2} \right\}
$$

<a id="reading-ridge-shrinkage"></a>

### Ridge 如何得到更小、更稳定的系数

继续使用 $\mathbf X=I_3$、$\mathbf Y=(3,0.4,-2)^T$。每个坐标需要最小化

$$
(z-b)^2+\lambda b^2.
$$

令导数为零，得到 $\widehat b=z/(1+\lambda)$。在 $\lambda=2$ 时，

$$
\widehat\beta_{\mathrm{Ridge}}=(1,\;0.4/3,\;-2/3)^T.
$$

与前面的 LASSO 相比，三个系数都向零缩小，原本非零的坐标没有因这个收缩公式而归零。LASSO 的绝对值在零点保留一个尖角；Ridge 的二次惩罚在零点是平滑的，因此这两种惩罚产生了不同的选择效果。

在两列相同的例子中，给定总贡献 $\beta_1+\beta_2=s$ 后，$\beta_1^2+\beta_2^2$ 在 $\beta_1=\beta_2=s/2$ 时最小。Ridge 因而倾向于把贡献分给相同或相近的特征，减少“大正系数和大负系数相互抵消”这一类不稳定表达。

这里的课件公式对写进 $\beta$ 的全部系数施加惩罚。实际回归常将截距单独处理，不惩罚截距，或先中心化再估计其他系数；那时系数收缩到零表示回到一个常数预测，而不一定回到数值零。

<a id="section-28"></a>

## 岭回归估计量的推导

- 记目标函数为：

$$
F (\beta) = \left(\mathbf {Y} - \mathbf {X} \beta\right) ^ {T} \left(\mathbf {Y} - \mathbf {X} \beta\right) + \lambda \beta^ {T} \beta
$$

- 利用 F 的凸性和可微性，通过求解下式得到解：

$$
\nabla F (\beta) = 2 \mathbf {X} ^ {T} (\mathbf {X} \beta - \mathbf {Y}) + 2 \lambda \beta = 0
$$

- 解为：

$$
\widehat {\beta} _ {\lambda} = \left(\mathbf {X} ^ {T} \mathbf {X} + \lambda I _ {d}\right) ^ {- 1} \mathbf {X} ^ {T} \mathbf {Y}
$$

因为 $\mathbf X^T\mathbf X+\lambda I_d$ 总是可逆的。

- 当 d 很大时，计算仍然困难……

<a id="reading-ridge-eigenvalues"></a>

### 为什么加上 λI 就能求解

对任意非零向量 $v$，只要 $\lambda>0$，

$$
v^T(\mathbf X^T\mathbf X+\lambda I_d)v
=\|\mathbf Xv\|^2+\lambda\|v\|^2>0.
$$

因此这个矩阵正定、可逆。原本为零的特征值被提高到 $\lambda$，很小的特征值也被抬高：数值上减弱了小分母造成的放大，统计上对应限制系数的幅度。这两种解释导向同一个 Ridge 公式。[正则化最小二乘](https://www.seas.ucla.edu/~vandenbe/133A/lectures/mols.pdf)

<details>
<summary>推导：在奇异向量方向上看收缩</summary>

设 $\mathbf X=U\Sigma V^T$，非零奇异值为 $s_j$。最小二乘在第 $j$ 个方向使用因子 $1/s_j$，Ridge 使用

$$
\frac{s_j}{s_j^2+\lambda}
=\frac{s_j^2}{s_j^2+\lambda}\frac1{s_j}.
$$

也就是说，相对于该方向上的最小二乘系数，Ridge 乘了一个介于 $0$ 与 $1$ 之间的收缩因子。$s_j$ 很小时，数据在这个方向上提供的约束很弱，收缩就更强。若 $s_j=0$，Ridge 把这个数据不可见的方向设为零。

在非零方向上，$\lambda\to0$ 时逐渐恢复最小二乘；有秩亏时，整体极限对应最小范数的最小二乘解。增加 $\lambda$ 会增加收缩，也会改变偏差，因而仍需要选择合适的强度。

</details>

<a id="section-29"></a>

## 对偶优化问题：表述与 KKT 条件

<a id="reading-dual-dimensions"></a>

前面的公式求一个 $d$ 维系数向量，需要处理 $d\times d$ 的矩阵。另一种表示改为给 $n$ 个训练样本分配权重，处理 $n\times n$ 的矩阵：

| 表示 | 主要矩阵 | 矩阵中的一项表示什么 |
|---|---|---|
| 参数表示 | $\mathbf X^T\mathbf X$，大小 $d\times d$ | 两个特征列在所有样本上的内积 |
| 样本表示 | $\mathbf X\mathbf X^T$，大小 $n\times n$ | 两个样本特征向量的内积 |

当 $n$ 比 $d$ 小很多时，后一种表示可能更省计算。两者描述同一个 Ridge 问题。引入残差变量 $r$，是为了把平方误差与参数惩罚暂时分开；拉格朗日乘子把关系 $r=\mathbf X\beta-\mathbf Y$ 放回目标函数。此处只有等式约束，下面的驻点关系还必须与这条约束一起成立。

- 岭回归优化的等价表述：

$$
\min _ {\beta \in \mathbb {R} ^ {d}, r \in \mathbb {R} ^ {n}} \left\{\frac {1}{2} \| r \| ^ {2} + \frac {\lambda}{2} \| \beta \| ^ {2} \right\} \quad \text{满足} r = \mathbf {X} \beta - \mathbf {Y}
$$

- 乘子向量为 $\alpha$ 的拉格朗日表述：

$$
\mathcal {L} (\beta , r, \alpha) = \frac {1}{2} \| r \| ^ {2} + \frac {\lambda}{2} \| \beta \| ^ {2} + \alpha^ {T} (r - \mathbf {X} \beta + \mathbf {Y})
$$

- Karush–Kuhn–Tucker 条件：令关于原变量 $\beta , r ,$ 的梯度为零，得到：

$$
\beta (\alpha) = \frac {1}{\lambda} \mathbf {X} ^ {T} \alpha \quad \text{且} \quad r (\alpha) = - \alpha
$$

<a id="section-30"></a>

## 对偶优化问题：求解

- 于是，岭回归优化的一种等价表述为：

$$
\mathcal {L} (\beta (\alpha), r (\alpha), \alpha) = \frac {1}{2} \| \alpha \| ^ {2} + \frac {1}{2 \lambda} \| \mathbf {X} ^ {T} \alpha \| + \alpha^ {T} \left(- \alpha - \frac {1}{\lambda} \mathbf {X X} ^ {T} \alpha + \mathbf {Y}\right)
$$

> **译注：** 原课件的 $\|\mathbf X^T\alpha\|$ 漏了平方。补上平方后，代回并整理得到对偶函数 $g(\alpha)=\alpha^T\mathbf Y-\tfrac12\|\alpha\|^2-\tfrac1{2\lambda}\|\mathbf X^T\alpha\|^2$，对偶问题是最大化该函数。原文的代入中间式完整保留在上方。

- 解为：

$$
\widehat {\alpha} = \lambda \left(\mathbf {X X} ^ {T} + \lambda I _ {n}\right) ^ {- 1} \mathbf {Y} \quad \text{且} \quad \widehat {\beta} = \frac {1}{\lambda} \mathbf {X} ^ {T} \widehat {\alpha}
$$

<a id="section-31"></a>

## 对偶优化问题：结果的解释

- 对 $x \in \mathbb { R } ^ { d }$ 的预测可用 α 表示。

$$
x ^ {T} \widehat {\beta} = \frac {1}{\lambda} x ^ {T} \mathbf {X} ^ {T} \widehat {\alpha} = \frac {1}{\lambda} \sum_ {i = 1} ^ {n} \widehat {\alpha} _ {i} x ^ {T} X _ {i}
$$

- 可以利用恒等式：

$\pmb { \mathsf { X } } ^ { T } \left( \pmb { \mathsf { X } } \pmb { \mathsf { X } } ^ { T } + \lambda \pmb { I } _ { n } \right) ^ { - 1 } = \left( \pmb { \mathsf { X } } ^ { T } \pmb { \mathsf { X } } + \lambda \pmb { I } _ { d } \right) ^ { - 1 } \pmb { \mathsf { X } } ^ { T }$ 来验证两个解相同。

- 重要观察：优化与函数求值只需要 $x ^ { \prime } s$ 与数据点 $X _ { i } ^ { \prime } s$ 之间的两两内积。

<a id="reading-dual-to-kernel"></a>

### 一次预测可以由与训练样本的内积组成

为简化下面的记号，令 $c=\widehat\alpha/\lambda$。代入前面的结果，有

$$
c=(\mathbf X\mathbf X^T+\lambda I_n)^{-1}\mathbf Y,\qquad
\widehat\beta=\mathbf X^Tc,\qquad
\widehat h(x)=\sum_{i=1}^{n}c_i\,x^TX_i.
$$

这些 $c_i$ 是可正可负的线性组合权重，不是概率。训练时只需要所有 $X_i^TX_j$，预测时只需要新输入与各训练点的 $x^TX_i$。这就是后面核方法可以接入的位置。

<details>
<summary>推导：把 KKT 条件连成一个线性系统</summary>

由 $\beta=\mathbf X^T\alpha/\lambda$、$r=-\alpha$ 和 $r=\mathbf X\beta-\mathbf Y$，

$$
-\alpha=\frac1\lambda\mathbf X\mathbf X^T\alpha-\mathbf Y,
\qquad
(\mathbf X\mathbf X^T+\lambda I_n)\alpha=\lambda\mathbf Y.
$$

解出 $\alpha$ 后再代回 $\beta$，便得到同一个 Ridge 解。优化时只需解这个线性系统，无须先构造矩阵的显式逆。

</details>

<a id="section-32"></a>

## Elastic Net：兼得 LASSO 与 Ridge 的优点？

- 动机（引自 Zou 与 Hastie，2005）：

(a) 在 $p > n { \mathrm { ~ c a s e } }$ 的情形下，由于凸优化问题自身的性质，LASSO 在达到饱和之前最多选择 n 个变量。对于变量选择方法，这似乎是一项限制。此外，除非系数的 $L _ { \mathrm { l } } \mathrm { - n o r m }$ 上界小于某个值，否则 LASSO 不是良好定义的。

(b) 如果一组变量之间的两两相关性非常高，LASSO 倾向于只从中选择一个变量，而不在意具体选中哪个。参见第 2.3 节。

(c) 对通常的 $n > p$ 情形，如果预测变量之间高度相关，经验上观察到 LASSO 的预测性能不如岭回归（Tibshirani，1996）。

> **译注：** 以上是原课件引用 Zou 与 Hastie（2005）的论述，不能脱离该文的条件把它解释为所有 LASSO 问题都不存在解或都不唯一。

- 组合 $\ell _ { 1 }$ 与 $\ell _ { 2 }$ 惩罚。

$$
\widehat {\beta} _ {\lambda} \in \underset {\beta \in \mathbb {R} ^ {d}} {\arg \min} \left\{\| \mathbf {Y} - \mathbf {X} \beta \| ^ {2} + \lambda \| \beta \| _ {1} + \mu \| \beta \| _ {2} ^ {2} \right\}
$$

<a id="reading-elastic-net-example"></a>

### 同时保留稀疏性与相关变量的共同贡献

继续在正交设计的小例子中计算，Elastic Net 的单个坐标目标为

$$
(z-b)^2+\lambda|b|+\mu b^2,
$$

其解为

$$
\widehat b_{\mathrm{EN}}
=\frac{\operatorname{sign}(z)(|z|-\lambda/2)_+}{1+\mu}.
$$

先由绝对值惩罚产生软阈值，再由二次惩罚进一步收缩。对 $\mathbf Y=(3,0.4,-2)^T$，取 $\lambda=2$、$\mu=1$，三种方法的结果为：

| 方法 | 本例采用的惩罚 | 估计系数 |
|---|---|---|
| LASSO | $2\lVert\beta\rVert_1$ | $(2,0,-1)$ |
| Ridge | $2\lVert\beta\rVert_2^2$ | $(1,0.4/3,-2/3)$ |
| Elastic Net | $2\lVert\beta\rVert_1+\lVert\beta\rVert_2^2$ | $(1,0,-0.5)$ |

再看两个完全相同的特征。若它们需要提供总贡献 $s>0$，LASSO 对任意非负分配 $\beta_1+\beta_2=s$ 都收取同样的 $\ell_1$ 代价 $s$；加入二次项以后，均匀分配 $s/2,s/2$ 的代价最小。因此 Elastic Net 能在保留稀疏机制的同时，鼓励相关特征共同承担预测。

当 $\mu>0$ 时，二次项还使这个系数优化问题严格凸，因而系数解唯一。系数仍可以为负；如果应用确实要求非负，就要另外写出非负约束。[Elastic Net 的目标与相关特征](https://scikit-learn.org/stable/modules/linear_model.html#elastic-net)

<a id="section-33"></a>

## LASSO 与 Elastic Net：正则化路径比较

![image](<Images/02_LM/image_008.jpg>)

![image](<Images/02_LM/image_009.jpg>)

<a id="reading-regularization-paths"></a>

读路径图时，每条曲线对应一个特征，纵坐标给出该特征的系数；横坐标可能画 $\lambda$、$\log\lambda$ 或某种系数范数比例，要先看原图标注的增减方向。固定一个横坐标，就得到某个正则化强度下的完整系数向量。

观察曲线何时离开零，可以看到特征怎样进入模型；观察多条相关曲线怎样一起变化，可以理解共同贡献。曲线的交叉、负系数和变量退出路径都可能有合理的统计原因。图中某个例子的表现，不构成 Elastic Net 保证所有系数非负、路径不交叉的性质，也不能仅按进入先后给变量排出普遍的“真实重要性”顺序。

<a id="section-34"></a>

## 超参数调整：交叉验证

- 如何选择参数 λ 和 $\mu ?$？它们称为超参数、平滑参数或正则化参数。
- 这是控制机器学习方法过拟合效应时普遍遇到的问题。
- 交叉验证过程将在后续课程中展开。

<a id="reading-cross-validation"></a>

### 一次交叉验证到底做什么

参数 $\beta$ 由训练目标求出，超参数 $\lambda$ 决定训练目标本身。要比较多个 $\lambda$，需要观察各自训练出的模型在未参与本次拟合的数据上表现如何。

例如，先留出最终测试集，把其余 9 条开发数据分成三折：第 1–3 条、第 4–6 条、第 7–9 条。对每个候选 $\lambda$，依次用其中两折拟合，在剩下一折计算平均平方误差，三次轮换后取平均。下面是一组说明计算过程的示意结果：

| $\lambda$ | 第 1 折验证误差 | 第 2 折验证误差 | 第 3 折验证误差 | 平均 |
|---:|---:|---:|---:|---:|
| 0 | 0.92 | 1.10 | 0.98 | 1.00 |
| 0.5 | 0.55 | 0.60 | 0.65 | 0.60 |
| 5 | 1.20 | 1.10 | 1.30 | 1.20 |

三个候选、每个三折，共需要拟合 9 次。这里选 $\lambda=0.5$，再用全部 9 条开发数据重新拟合一次，最后用一直留出的测试集评估。这样每次验证都在模型没用来拟合的样本上进行，同时让开发数据轮流承担训练和验证的角色。[交叉验证流程](https://scikit-learn.org/stable/modules/cross_validation.html)

### 为什么先统一特征尺度

同样的长度，如果从米改成厘米，数值变成原来的 100 倍；为了维持相同预测，对应系数只需变成原来的 $1/100$。预测含义完全相同，$\ell_1$ 惩罚却变成原来的 $1/100$，平方 $\ell_2$ 惩罚变成原来的 $1/10000$。因此带系数惩罚的模型会受到计量单位影响，通常需要先对可比较的数值特征中心化、标准化，再拟合。

交叉验证时，每一折的均值、标准差都只从该折训练部分计算，再用于变换验证部分；选择超参数后，再在全部开发数据上重新拟合这些预处理量与模型。Pipeline 可以把预处理和回归放在同一套训练流程中。[交叉验证中的数据变换](https://scikit-learn.org/stable/modules/cross_validation.html#data-transformation-with-held-out-data)

<details>
<summary>延伸：λ 的写法与多个超参数的搜索成本</summary>

本讲主要使用 $\mathrm{RSS}+\lambda P(\beta)$。若改写成 $\mathrm{RSS}/n+\lambda'P(\beta)$，要表示同一个问题，应取 $\lambda'=\lambda/n$。软件或教材还可能在平方损失前放 $1/2$，因此比较数值时要先看完整目标函数。

Elastic Net 需要比较 $(\lambda,\mu)$ 的组合，核方法还可能增加核宽度或次数。如果 10 个超参数各尝试 5 个值，完整网格就有 $5^{10}=9,765,625$ 个组合，每个组合还要做若干折训练。困难主要来自穷举网格的成本；实际可以缩小搜索范围，使用随机搜索或其他逐步搜索策略，交叉验证作为评估方式仍然可以保留。

划分方式也要符合预测任务。时间序列通常用过去训练、在后续时间验证；同一对象的多条关联观测可能需要按对象分组。这样验证过程才更接近将来真正使用模型的情形。

</details>

<a id="section-35"></a>

## 练习：比较三种惩罚

- 考虑如下玩具问题：$Y \sim { \mathcal { N } } _ { 1 } ( \beta ^ { * } , 1 )$，其中 $\beta$ 是实值参数，$( d = 1 )$。
- 分别最小化下面三个函数，求出相应的三个估计量：

$$
(\mathrm{i}) \frac {1}{2} (Y - \beta) ^ {2} + \lambda , (\mathrm{ii}) \frac {1}{2} (Y - \beta) ^ {2} + \lambda | \beta |, (\mathrm{iii}) \frac {1}{2} (Y - \beta) ^ {2} + \lambda \beta^ {2}
$$

- 以无约束最小二乘估计为自变量，画出这些估计量的函数图像，并解释惩罚估计过程中使用的术语：硬阈值、软阈值、收缩。

<a id="kernels"></a>

<a id="reading-penalty-exercise"></a>

### 解答：把三种作用放在同一条数轴上

**题目第一项需要辨清。** 原 PDF 第 64 页也写成了 $\tfrac12(Y-\beta)^2+\lambda$。其中 $\lambda$ 是与 $\beta$ 无关的常数，按字面求解仍是 $\widehat\beta=Y$。若要得到题目要求比较的硬阈值，应改为 $\ell_0$ 惩罚 $\lambda\mathbb I\{\beta\neq0\}$。下面保留这个区别，同时计算三种通常要比较的估计。

令 $\lambda>0$，无惩罚的最小二乘解是 $Y$：

| 惩罚 | 最优估计 | 对观测的作用 |
|---|---|---|
| $\lambda\mathbb I\{\beta\neq0\}$ | $\widehat\beta=Y\mathbb I\{\lvert Y\rvert>\sqrt{2\lambda}\}$，阈值处见下文 | 小值归零，大值原样保留：硬阈值 |
| $\lambda\lvert\beta\rvert$ | $\widehat\beta=\operatorname{sign}(Y)(\lvert Y\rvert-\lambda)_+$ | 小值归零，大值也向零缩短：软阈值 |
| $\lambda\beta^2$ | $\widehat\beta=Y/(1+2\lambda)$ | 按比例缩小：收缩 |

在硬阈值的边界 $|Y|=\sqrt{2\lambda}$，$\widehat\beta=0$ 与 $\widehat\beta=Y$ 都达到最小值。取 $\lambda=1$，当 $Y=3$ 时，三个结果依次为 $3,2,1$；当 $Y=0.5$ 时，依次为 $0,0,1/6$。

![硬阈值、软阈值与 Ridge 收缩；横轴为无惩罚估计 Y，纵轴为惩罚后的估计，λ=1](Images/02_LM/penalties_comparison.png)

灰色虚线是无惩罚估计，也是原题常数惩罚版本的解。蓝线展示 $\ell_0$、$\ell_1$ 和平方 $\ell_2$ 惩罚的结果。硬阈值在边界处允许两个最优值，图中分别标出；软阈值连续地接到零；Ridge 始终是一条斜率较小的直线。

本题平方损失前有 $1/2$，所以 LASSO 阈值是 $\lambda$，Ridge 分母是 $1+2\lambda$。前面采用 $(z-b)^2$ 的例子对应阈值 $\lambda/2$ 和分母 $1+\lambda$；两处的差别来自目标函数中的比例。

<details>
<summary>推导：硬阈值、软阈值和收缩分别怎样算出来</summary>

对 $\ell_0$ 惩罚，取 $\beta=0$ 时目标值为 $Y^2/2$；如果保留非零系数，最好的选择是 $\beta=Y$，目标值为 $\lambda$。比较两者，只有 $Y^2/2>\lambda$ 才值得保留。等号时两种选择都最优；$Y=0$ 时直接取零。

对 $\ell_1$ 惩罚，$\beta>0$ 时导数为 $\beta-Y+\lambda$，$\beta<0$ 时为 $\beta-Y-\lambda$。两侧解分别为 $Y-\lambda$ 和 $Y+\lambda$，只有落在相应半轴时才有效；剩下的 $|Y|\leq\lambda$ 由零点接住。

对平方 $\ell_2$ 惩罚，导数处处存在：

$$
\beta-Y+2\lambda\beta=0
\quad\Longrightarrow\quad
\widehat\beta=\frac{Y}{1+2\lambda}.
$$

</details>

<a id="section-36"></a>

## B. 估计非线性函数

### 从非线性到线性：多项式回归例子

- 考虑维度为 $d = 2$ 的多项式回归：它对应一个维度为 $d ^ { \prime } = 7$ 的线性模型，特征向量为：

$$
\Phi (x _ {1}, x _ {2}) = \left(1, \sqrt {2} x _ {1}, \sqrt {2} x _ {2}, \sqrt {2} x _ {1} x _ {2}, x _ {1} ^ {2}, x _ {2} ^ {2}\right) ^ {T}
$$

> **译注：** 原页写作 7 维，但所列特征向量只有 6 个分量；与该向量一致的维度应为 6。

- 注意：

$$
\Phi (x) ^ {T} \Phi (x ^ {\prime}) = (x ^ {T} x ^ {\prime} + 1) ^ {2}
$$

- 称 $K ( x , x ^ { \prime } ) = ( x ^ { T } x ^ { \prime } + 1 ) ^ { 2 }$ 为多项式核。核具有这样一个性质：可以表示为高维特征空间中的内积。特征空间是原始 d 维输入空间经 Φ 映射得到的像空间，其维度可能非常大。

<a id="reading-feature-map"></a>

### 展开特征，与直接计算内积

上面的六个特征允许模型表达常数项、两个一次项、交叉项和两个平方项。函数对 $(x_1,x_2)$ 可以弯曲，但对这六个特征的系数仍然线性。

取 $x=(1,2)^T$、$z=(2,0)^T$。按照课件给出的顺序，

$$
\Phi(x)=(1,\sqrt2,2\sqrt2,2\sqrt2,1,4)^T,\qquad
\Phi(z)=(1,2\sqrt2,0,0,4,0)^T.
$$

展开后计算内积，得到 $1+4+4=9$；直接计算核函数，得到 $(x^Tz+1)^2=(2+1)^2=9$。两条路径给出同一个数。特征中的 $\sqrt2$ 正是为了让交叉项的系数与平方展开一致。

如果算法只需要这样的内积，就可以用核函数一次算出结果，不必显式列出全部特征。多项式次数或原始输入维度很大时，这种表示尤其有用。[从特征映射理解核方法](https://cs229.stanford.edu/notes2021fall/cs229-notes3.pdf)

<a id="section-37"></a>

## 核的魔力：核岭回归

- 在线性岭回归中已经看到，无论问题表述还是预测求值，真正用到的依赖数据的量，只有 $X _ { i } ^ { T } X _ { j }$ 与 $x ^ { T } X _ { i }$ 的两两内积。
- 基本上，可以将任意一个内积替换为相应点对的核函数值，而完全不改变求解的算法复杂度。于是能够估计下列非线性函数中的参数 $\alpha _ { i }$：

> **译注：** 这里保留原文的算法复杂度说法。替换内积不改变基于 Gram 矩阵求解的框架，但具体核函数的求值代价与存储成本仍需另外考虑。

$$
f (x) = \sum_ {i = 1} ^ {n} \alpha_ {i} K (x, X _ {i})
$$

<a id="reading-kernel-ridge-example"></a>

### 从核矩阵到一个实际预测

定义 $n\times n$ 的核矩阵 $\mathbf K$，其中 $K_{ij}=K(X_i,X_j)$。沿用前面 $c=\widehat\alpha/\lambda$ 的记号，核岭回归可以写成

$$
(\mathbf K+\lambda I_n)c=\mathbf Y,\qquad
\widehat f(x)=\sum_{i=1}^{n}c_iK(x,X_i).
$$

上方课件把直接乘在核函数前的权重记作 $\alpha_i$，相当于这里的 $c_i$；它已吸收前面对偶乘子中的 $1/\lambda$。

只取两个一维训练输入 $X_1=0,X_2=1$，响应 $\mathbf Y=(0,1)^T$，使用 $K(x,z)=(1+xz)^2$ 和 $\lambda=1$。则

$$
\mathbf K=\begin{pmatrix}1&1\\1&4\end{pmatrix},\qquad
\begin{pmatrix}2&1\\1&5\end{pmatrix}c
=\begin{pmatrix}0\\1\end{pmatrix},
\qquad
c=\begin{pmatrix}-1/9\\2/9\end{pmatrix}.
$$

预测函数为

$$
\widehat f(x)=-\frac19+\frac29(1+x)^2.
$$

在新输入 $x=2$ 处，预测值是 $-1/9+2\times9/9=17/9$。求解过程只是一个两元线性系统，得到的函数却对原始输入呈二次关系。正的正则化强度允许训练点上保留残差，因此这里没有要求曲线穿过两个观测。[核岭回归](https://scikit-learn.org/stable/modules/kernel_ridge.html)

<details>
<summary>推导：核空间里的惩罚是什么，怎样判断核是否合适</summary>

设显式特征矩阵为 $\mathbf\Phi$，在这个空间做 Ridge：

$$
\min_w\|\mathbf Y-\mathbf\Phi w\|^2+\lambda\|w\|^2.
$$

最优 $w$ 位于训练特征向量张成的空间内：与这个空间正交的分量不改变训练预测，却会增加平方范数惩罚，因此最优解会去掉它。于是可以写成 $w=\mathbf\Phi^Tc$。此时 $\mathbf K=\mathbf\Phi\mathbf\Phi^T$，预测向量为 $\mathbf Kc$，惩罚项为

$$
\lambda\|w\|^2=\lambda c^T\mathbf Kc.
$$

因此核岭回归保留的是特征空间中的 Ridge 惩罚，直接对 $c$ 使用 $\lambda\|c\|^2$ 一般会得到另一个问题。

一个函数要充当实值内积核，需要对称，并且对任意有限样本组产生半正定的 Gram 矩阵。若 $K(x,z)=\langle\Phi(x),\Phi(z)\rangle$，则对任意权重向量 $a$，

$$
a^T\mathbf Ka=\left\|\sum_i a_i\Phi(X_i)\right\|^2\geq0.
$$

这个条件让 $\mathbf K+\lambda I_n$ 在 $\lambda>0$ 时可逆。任意人为设计的“相似度”不一定满足它；核方法所用的相似关系需要符合这种内积结构。

</details>

<a id="section-38"></a>

## 基本核的例子

- 线性核：$\operatorname { K } ( \mathbf { x } , \mathbf { z } ) = \mathbf { x } \cdot z$。
- 多项式核：$\operatorname { K } ( \mathbf { x } , z ) = ( \mathbf { x } \cdot z ) ^ { \mathrm { d } } \circ r \operatorname { K } ( \mathbf { x } , z ) = ( 1 + \mathbf { x } \cdot z ) ^ { \mathrm { d } }$。
- 高斯核：$\begin{array} { r } { \mathrm { K } ( \mathrm { x } , z ) = \exp \left[ - \frac { \left| \left| x - z \right| \right| ^ { 2 } } { 2 \sigma ^ { 2 } } \right] } \end{array}$。
- Laplace 核：$\begin{array} { r } { \mathrm { K } ( \mathrm { x } , z ) = \exp \left[ - \frac { | | x - z | | } { 2 \sigma ^ { 2 } } \right] } \end{array}$。

![image](<Images/02_LM/image_010.jpg>)

<a id="reading-kernel-shape"></a>

### 核函数决定怎样看待两个输入

线性核保留原特征的内积；多项式核引入特征间不同次数的组合。这里多项式公式里的指数 $d$ 表示次数，为避免与输入维度混淆，也可以把次数记成 $p$。

高斯核则随距离增大而减小。若两个点相距 $1$，取 $\sigma=0.1$ 时，核值为 $e^{-50}$，几乎为零；取 $\sigma=1$ 时，核值为 $e^{-1/2}\approx0.607$。较小的宽度把相互作用限制在更近的区域，较大的宽度把更远的样本也联系起来。宽度与正则化强度一起影响拟合，需要共同选择。

核确定的不只是一个相似度数值，也确定了特征空间里的距离。把两个特征向量之差的平方展开，就得到下面只含核值的公式。

$$
\begin{array}{l} d _ {K} \left(\mathbf {x} _ {1}, \mathbf {x} _ {2}\right) ^ {2} = \| \Phi \left(\mathbf {x} _ {1}\right) - \Phi \left(\mathbf {x} _ {2}\right) \| _ {\mathcal {H}} ^ {2} \\ \qquad = \langle \Phi \left(\mathbf {x} _ {1}\right) - \Phi \left(\mathbf {x} _ {2}\right), \Phi \left(\mathbf {x} _ {1}\right) - \Phi \left(\mathbf {x} _ {2}\right) \rangle_ {\mathcal {H}} \\ \qquad = \langle \Phi \left(\mathbf {x} _ {1}\right), \Phi \left(\mathbf {x} _ {1}\right) \rangle_ {\mathcal {H}} + \langle \Phi \left(\mathbf {x} _ {2}\right), \Phi \left(\mathbf {x} _ {2}\right) \rangle_ {\mathcal {H}} - 2 \langle \Phi \left(\mathbf {x} _ {1}\right), \Phi \left(\mathbf {x} _ {2}\right) \rangle_ {\mathcal {H}} \\ d _ {K} (\mathbf {x} _ {1}, \mathbf {x} _ {2}) ^ {2} = K (\mathbf {x} _ {1}, \mathbf {x} _ {1}) + K (\mathbf {x} _ {2}, \mathbf {x} _ {2}) - 2 K (\mathbf {x} _ {1}, \mathbf {x} _ {2}) \end{array}
$$

- 为处理字符串（文本、DNA 序列等）这样的结构化数据，人们设计了专门的核。
- 用于 DNA 序列的谱核示例：

核的定义

- $\mathbf{x} = \text{CGGSLIAMMWFGV}$ 的 3-spectrum（长度为 3 的子串谱）是：(CGG, GGS, GSL, SLI, LIA, IAM, AMM, MMW, MWF, WFG, FGV)。
- 令 $\Phi_u(\mathbf{x})$ 表示 $u$ 在 $\mathbf{x}$ 中的出现次数。$k$-spectrum 核定义为 $K(\mathbf{x}, \mathbf{x}') := \sum_{u \in A^k} \Phi_u(\mathbf{x}) \Phi_u(\mathbf{x}')$。

> **译注：** 原页称这是 DNA 序列示例，但字符串含有 DNA 四种碱基字母以外的字符；这里保留原例，不改变核的计数定义。

<a id="reading-string-kernel"></a>

### 字符串也能通过“共同出现的片段”比较

取长度为 2 的片段。字符串 ABABA 中，AB 出现 2 次、BA 出现 2 次；字符串 ABBA 中，AB、BB、BA 各出现 1 次。只列出可能有贡献的坐标 AB、BA、BB，两者的计数向量为

$$
\Phi(\mathrm{ABABA})=(2,2,0),\qquad
\Phi(\mathrm{ABBA})=(1,1,1),
$$

所以二者的谱核值为 $2\times1+2\times1+0\times1=4$。每种片段是一种特征，共同片段通过内积产生相似性。原始输入可以是符号串，进入算法的则是两两核值。

这种表示保留所选长度片段的局部顺序，但计数相同的字符串可能映射到同一特征向量。相应地，核诱导的距离可能让不同输入之间的距离为零，严格说一般是伪距离；如果特征映射能够区分所有输入，才得到真正的距离。

<a id="section-39"></a>

## 核机器学习估计：可行吗？

- 核函数具有良好的建模性质。
- 问题是：最小二乘意义下的惩罚优化是否可行？

<a id="reading-kernel-computation"></a>

### 省去特征展开以后，计算量转移到了哪里

核方法可以避免显式构造很高维甚至无限维的特征，却仍然需要处理样本之间的关系。标准的稠密核岭回归需要存储 $n\times n$ 的矩阵，存储量为 $O(n^2)$；常规直接分解求解约需 $O(n^3)$ 运算，构建核矩阵还要加上核函数的求值成本。

例如 $n=10,000$ 时，矩阵有一亿个元素，仅用双精度存储这一张矩阵就约需 $0.8$ GB，尚未计入分解等额外空间。对一个新输入的预测，通常还要计算与各训练样本的核值。因此，核方法绕开的是显式特征展开的困难，大样本量带来的成本仍要处理。

回到前面的两种表示：线性 Ridge 可以根据 $d$ 和 $n$ 选择较合适的求解方式；一般核方法主要围绕样本 Gram 矩阵展开。理解这一区别，也就能看出核技巧在哪个环节节省了工作、又在哪个环节留下了成本。

<a id="section-40"></a>

## C. 推广：应用于其他估计问题

### 惩罚优化：还有哪些变体？

- 到目前为止：由线性函数 $h \in \mathcal H$ 构成的假设类，以及不同的惩罚项。

$$
\text{准则} (h) = \text{训练误差} (h) + \lambda \text{惩罚项} (h)
$$

- 从现在起：使用其他损失函数来改变训练误差。

$$
\text{准则} (h) = \text{训练误差} (h) + \lambda \text{惩罚项} (h)
$$

几个例子：

岭回归：

$$
\min _ {\boldsymbol {\beta} \in \mathbb {R} ^ {p}} \frac {1}{n} \sum_ {i = 1} ^ {n} \frac {1}{2} (y _ {i} - \boldsymbol {\beta} ^ {\top} \mathbf {x} _ {i}) ^ {2} + \lambda \| \boldsymbol {\beta} \| _ {2} ^ {2}.
$$

线性 SVM：

$$
\min _ {\boldsymbol {\beta} \in \mathbb {R} ^ {p}} \frac {1}{n} \sum_ {i = 1} ^ {n} \max (0, 1 - y _ {i} \boldsymbol {\beta} ^ {\top} \mathbf {x} _ {i}) + \lambda \| \boldsymbol {\beta} \| _ {2} ^ {2}.
$$

逻辑回归：$\min_{\beta\in\mathbb R^p}\frac1n\sum_{i=1}^n\log\left(1+e^{-y_i\beta^T\mathbf x_i}\right)+\lambda\|\beta\|_2^2$。

![image](<Images/02_LM/image_011.jpg>)

<a id="reading-changing-the-loss"></a>

### 保留建模框架，改变“预测错了”的含义

平方损失适合直接比较数值预测与数值目标。二分类中，若标签 $y\in\{-1,1\}$，可以让模型输出分数 $s=\beta^Tx$，再用符号决定类别；乘积 $ys$ 称为间隔，它为正说明方向正确，为负说明方向错误。

线性 SVM 的 hinge 损失是 $\max(0,1-ys)$：方向正确但间隔不足时仍付出代价，间隔达到 $1$ 后该样本的损失为零。逻辑损失 $\log(1+e^{-ys})$ 则随间隔增加平滑下降。图中红色平方损失在预测超过目标数值以后又上升，绿色 hinge 损失达到阈值后变为零，蓝色逻辑损失逐渐趋近零。

这些方法都可以继续配合正则化、特征变换和验证流程。改变损失，是在改变任务中如何评价预测；改变惩罚，是在改变对解的结构与复杂度的要求。

- 其他任务：用于分类的线性模型。
- 表示问题：特征工程、变量选择、表示学习。
- 从线性模型到非线性模型：哪些部分可以保留？

<a id="reading-sources"></a>

<details>
<summary>来源与阅读说明</summary>

正文以原课件的完整中文译文为骨架，例子、练习、重复正文、公式、图表及文献均保留；图中文字保留原图语言。原课件错误与必要辨析在相应位置说明。课堂解释已融入概念所在段落，手算例子用于把定义与运算联系起来。

原始课堂记录：[转录 1](02_part1.md)、[转录 2](02_part2.md)、[转录 3](02_part3.md)。重复口头表达、课间安排、个人经历和未采用的旁支讨论仍可在原始记录中查阅，具体去向见[本讲整合与核对记录](Translation-audit/02_LM_classroom_integration.md)。

外部材料按问题选用：

- [UCLA：Least squares](https://www.seas.ucla.edu/~vandenbe/133A/lectures/ls.pdf)：投影与最小二乘。
- [UCLA：Multi-objective least squares](https://www.seas.ucla.edu/~vandenbe/133A/lectures/mols.pdf)：二次惩罚与正则化。
- [Stanford CS229：LASSO](https://cs229.stanford.edu/notes2021fall/lecture10-lasso-regression.pdf)：变量选择与系数路径。
- [scikit-learn：交叉验证](https://scikit-learn.org/stable/modules/cross_validation.html)：训练、验证及预处理的配合。
- [Stanford CS229：核方法](https://cs229.stanford.edu/notes2021fall/cs229-notes3.pdf)：特征映射、内积与核的条件。
- [scikit-learn：Elastic Net](https://scikit-learn.org/stable/modules/linear_model.html#elastic-net) 与[核岭回归](https://scikit-learn.org/stable/modules/kernel_ridge.html)：目标函数及方法之间的联系。
- [Friedman、Hastie、Tibshirani：Group LASSO 与 Sparse Group LASSO](https://arxiv.org/abs/1001.0736)：组稀疏与组内稀疏的区别。
- [Raissi、Perdikaris、Karniadakis：物理信息学习](https://arxiv.org/abs/1711.10561)：把方程信息加入学习目标的延伸阅读。

</details>
